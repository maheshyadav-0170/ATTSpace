const mongoose = require('mongoose');

const CommentSchema = new mongoose.Schema({
  author:  { type: String, required: true },
  text:    { type: String, required: true },
  created: { type: Date,   default: Date.now }
});

const StateChangeSchema = new mongoose.Schema({
  from:      { type: String, required: true },
  to:        { type: String, required: true },
  changedBy: { type: String, required: true },
  changedAt: { type: Date,   default: Date.now }
});

const IssueSchema = new mongoose.Schema({
  type:      { type: String, required: true, enum: [
                'Workspace Issue','Facility','Hardware','Network','Access / Permission','Other'
              ]},
  summary:   { type: String, required: true, maxlength: 160 },
  details:   { type: String, maxlength: 2000 },

  location:       { type: String, required: true },
  otherLocation:  { type: String },

  severity:  { type: String, required: true, enum: ['Minor','Moderate','Major','Critical'] },
  impact:    { type: String, required: true, enum: ['Single User','Team','Department / Floor','Entire Site'] },

  reporter:  { type: String, required: true },

  state:          { type: String, required: true, enum: [
                     'Open','In Progress','Awaiting Info','Resolved','Closed','Rejected'
                   ], default: 'Open' },
  stateHistory:   [ StateChangeSchema ],

  comments:  [ CommentSchema ],

  resolver:  { type: String },
  resolution: { type: String },
  resolvedAt: { type: Date },

  attachments: [{
    filename:   String,
    url:        String,
    uploadedBy: String,
    uploadedAt: { type: Date, default: Date.now }
  }]
}, {
  timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' }
});

module.exports = mongoose.model('Issue', IssueSchema);