const Issue = require('../models/Issue');
const { Types } = require('mongoose');
const logger = require('../utils/logger');
const { publishNotification } = require('../services/rabbitmqPublisher');

// Shared auth middleware pattern (expects Authorization: Bearer <token> and decoded attuid in token)
const { verify } = require('../services/jwtService');

async function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Unauthorized: No token provided' });
  try {
    const decoded = verify(token);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Unauthorized: Invalid or expired token' });
  }
}

// Simple admin guard (use after authMiddleware)
function adminOnly(req, res, next) {
  if (!req.user || req.user.role !== 'Administrator') {
    return res.status(403).json({ success: false, message: 'Admin access required' });
  }
  next();
}

// Build meta classification for client (viewer relationship & permissions)
function buildIssueMeta(issue, user) {
  const isReporter = issue.reporter === user.attuid;
  const isAdmin = user.role === 'Administrator';
  const reporterEditable = ['summary','details','impact','severity'];
  return {
    issueId: issue._id,
    viewer: user.attuid,
    viewerRole: user.role,
    isAdmin,
    isReporter,
    canEdit: isAdmin || isReporter,
    reporterEditableFields: reporterEditable,
    stateChangeAllowed: isAdmin || (isReporter && ['Resolved','Closed','Rejected'].includes(issue.state)),
    commentAllowed: isAdmin || isReporter,
    attachmentAllowed: isAdmin || isReporter
  };
}

// =============================
// Logging Helpers (professional logfmt style)
// =============================
function formatValue(v) {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  const str = String(v);
  // Quote if contains whitespace or special chars
  return /\s|"|=/.test(str) ? '"' + str.replace(/"/g, '\\"') + '"' : str;
}

function logLine(level, action, outcome, message, fields = {}) {
  const base = { action, outcome, msg: message, ...fields };
  const line = Object.entries(base)
    .filter(([,v]) => v !== undefined)
    .map(([k,v]) => `${k}=${formatValue(v)}`)
    .join(' ');
  logger[level](line);
}
function logSuccess(action, message, fields) { logLine('info', action, 'success', message, fields); }
function logError(action, err, fields) { logLine('error', action, 'error', err.message || err, fields); }

// =============================
// Core CRUD / Lifecycle Actions
// =============================
// Create Issue
async function createIssue(req, res) {
  try {
    const { type, summary, details, location, otherLocation, severity, impact } = req.body;
    if (!type || !summary || !location || !severity || !impact) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    const issue = new Issue({
      type,
      summary: summary.trim(),
      details: details?.trim(),
      location,
      otherLocation: location === 'Other' ? (otherLocation || '').trim() : undefined,
      severity,
      impact,
      reporter: req.user.attuid,
      stateHistory: [{ from: 'N/A', to: 'Open', changedBy: req.user.attuid }]
    });

    await issue.save();

    // Notify reporter and admins (simplified: we send to reporter; admin broadcast left for consumer or separate process)
    await publishNotification({
      attuid: req.user.attuid,
      title: 'Issue Submitted',
      body: `Your issue (${issue.summary}) has been submitted.`
    });

    // placeholder admin broadcast (use special attuid tag or queue for admin consumer)
    await publishNotification({
      attuid: 'ADMIN_BROADCAST',
      title: 'New Issue Reported',
      body: `${req.user.attuid} reported: ${issue.summary}`
    });

  logSuccess('createIssue', 'issue created', {
    issueId: issue._id,
    reporter: issue.reporter,
    type: issue.type,
    severity: issue.severity,
    impact: issue.impact,
    state: 'Open',
    stateHistoryLength: issue.stateHistory.length
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('createIssue', err);
    return res.status(500).json({ success: false, message: 'Failed to create issue', error: err.message });
  }
}

// Fetch single issue (permission: reporter or admin)
async function fetchIssue(req, res) {
  try {
    const { id } = req.body; // using POST patterns like other services
    if (!id) return res.status(400).json({ success: false, message: 'id required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });

    if (issue.reporter !== req.user.attuid && req.user.role !== 'Administrator') {
      return res.status(403).json({ success: false, message: 'Forbidden' });
    }
  logSuccess('fetchIssue', 'issue fetched', {
    issueId: issue._id,
    viewer: req.user.attuid,
    viewerRole: req.user.role,
    reporter: issue.reporter,
    state: issue.state,
    commentCount: issue.comments.length,
    attachmentCount: issue.attachments.length
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('fetchIssue', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch issue', error: err.message });
  }
}

// Fetch all issues (admins) or my issues for regular user
async function fetchAllIssues(req, res) {
  try {
    const filter = req.user.role === 'Administrator' ? {} : { reporter: req.user.attuid };
  const issues = await Issue.find(filter).sort({ createdAt: -1 });
  const enriched = issues.map(i => ({ issue: i, meta: buildIssueMeta(i, req.user) }));
  logSuccess('fetchAllIssues', 'issues list fetched', {
    viewer: req.user.attuid,
    viewerRole: req.user.role,
    count: enriched.length,
    scope: req.user.role === 'Administrator' ? 'all' : 'own'
  });
  return res.json({ success: true, count: enriched.length, issues: enriched });
  } catch (err) {
    logError('fetchAllIssues', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch issues', error: err.message });
  }
}

// Update issue fields (Admins or reporter for limited fields)
async function updateIssue(req, res) {
  try {
    const { id, updates } = req.body;
    if (!id || !updates) return res.status(400).json({ success: false, message: 'id and updates required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });

    const isReporter = issue.reporter === req.user.attuid;
    const isAdmin = req.user.role === 'Administrator';
    if (!isReporter && !isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });

    // Allowed fields for reporter
    const reporterEditable = ['summary', 'details', 'impact', 'severity'];

    Object.keys(updates).forEach(key => {
      if (isAdmin || reporterEditable.includes(key)) {
        if (key === 'state' && updates.state && updates.state !== issue.state) {
          const prev = issue.state;
            issue.state = updates.state;
            issue.stateHistory.push({ from: prev, to: updates.state, changedBy: req.user.attuid });
        } else if (key !== 'state') {
          issue[key] = updates[key];
        }
      }
    });

    if (issue.state === 'Resolved' && !issue.resolvedAt) {
      issue.resolvedAt = new Date();
    }

    await issue.save();

    // Notify reporter if admin changed state
    if (isAdmin && !isReporter && updates.state) {
      await publishNotification({
        attuid: issue.reporter,
        title: 'Issue Status Updated',
        body: `Your issue (${issue.summary}) is now ${issue.state}.`
      });
    }

  logSuccess('updateIssue', 'issue updated', {
    issueId: issue._id,
    actor: req.user.attuid,
    actorRole: req.user.role,
    state: issue.state,
    resolved: !!issue.resolvedAt,
    comments: issue.comments.length,
    attachments: issue.attachments.length
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('updateIssue', err);
    return res.status(500).json({ success: false, message: 'Failed to update issue', error: err.message });
  }
}

// Add comment
async function addComment(req, res) {
  try {
    const { id, text } = req.body;
    if (!id || !text) return res.status(400).json({ success: false, message: 'id and text required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });

    const isReporter = issue.reporter === req.user.attuid;
    const isAdmin = req.user.role === 'Administrator';
    if (!isReporter && !isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });

    issue.comments.push({ author: req.user.attuid, text: text.trim() });
    await issue.save();

    // Notify counterpart
    const targetAttuid = isReporter ? 'ADMIN_BROADCAST' : issue.reporter;
    await publishNotification({
      attuid: targetAttuid,
      title: 'New Issue Comment',
      body: `${req.user.attuid} commented on issue: ${issue.summary}`
    });

  logSuccess('addComment', 'comment added', {
    issueId: issue._id,
    commenter: req.user.attuid,
    role: req.user.role,
    comments: issue.comments.length
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('addComment', err);
    return res.status(500).json({ success: false, message: 'Failed to add comment', error: err.message });
  }
}

// Delete issue (admin only)
async function deleteIssue(req, res) {
  try {
    const { id } = req.body;
    if (!id) return res.status(400).json({ success: false, message: 'id required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const issue = await Issue.findByIdAndDelete(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
  logSuccess('deleteIssue', 'issue deleted', {
    issueId: id,
    actor: req.user.attuid,
    actorRole: req.user.role
  });
    return res.json({ success: true, deleted: id });
  } catch (err) {
    logError('deleteIssue', err);
    return res.status(500).json({ success: false, message: 'Failed to delete issue', error: err.message });
  }
}

// =============================
// Additional / Extended API
// =============================

// Explicit fetch of reporter's issues (even though fetchAllIssues covers this; kept for clarity)
async function fetchMyIssues(req, res) {
  try {
  const issues = await Issue.find({ reporter: req.user.attuid }).sort({ createdAt: -1 });
  const enriched = issues.map(i => ({ issue: i, meta: buildIssueMeta(i, req.user) }));
  logSuccess('fetchMyIssues', 'reporter issues fetched', {
    reporter: req.user.attuid,
    count: enriched.length
  });
  return res.json({ success: true, count: enriched.length, issues: enriched });
  } catch (err) {
    logError('fetchMyIssues', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch my issues', error: err.message });
  }
}

// Fetch by state (admins get all in that state, reporters only their own)
async function fetchByState(req, res) {
  try {
    const { state } = req.body;
    if (!state) return res.status(400).json({ success: false, message: 'state required' });
    const base = req.user.role === 'Administrator' ? {} : { reporter: req.user.attuid };
  const issues = await Issue.find({ ...base, state }).sort({ updatedAt: -1 });
  const enriched = issues.map(i => ({ issue: i, meta: buildIssueMeta(i, req.user) }));
  logSuccess('fetchByState', 'issues fetched by state', {
    state,
    viewer: req.user.attuid,
    role: req.user.role,
    count: enriched.length
  });
  return res.json({ success: true, count: enriched.length, issues: enriched });
  } catch (err) {
    logError('fetchByState', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch by state', error: err.message });
  }
}

// Text / filtered search
async function searchIssues(req, res) {
  try {
    const { text, types, severities, impacts, states, fromDate, toDate } = req.body;
    const filter = req.user.role === 'Administrator' ? {} : { reporter: req.user.attuid };
    if (text) {
      filter.$or = [
        { summary: { $regex: text, $options: 'i' } },
        { details: { $regex: text, $options: 'i' } }
      ];
    }
    if (Array.isArray(types) && types.length) filter.type = { $in: types };
    if (Array.isArray(severities) && severities.length) filter.severity = { $in: severities };
    if (Array.isArray(impacts) && impacts.length) filter.impact = { $in: impacts };
    if (Array.isArray(states) && states.length) filter.state = { $in: states };
    if (fromDate || toDate) {
      filter.createdAt = {};
      if (fromDate) filter.createdAt.$gte = new Date(fromDate);
      if (toDate) filter.createdAt.$lte = new Date(toDate);
    }
  const issues = await Issue.find(filter).sort({ createdAt: -1 });
  const enriched = issues.map(i => ({ issue: i, meta: buildIssueMeta(i, req.user) }));
  logSuccess('searchIssues', 'issue search executed', {
    viewer: req.user.attuid,
    role: req.user.role,
    results: enriched.length,
    textQuery: req.body.text ? 'yes' : 'no',
    filters: ['types','severities','impacts','states','fromDate','toDate'].filter(k => !!req.body[k]).join('|') || 'none'
  });
  return res.json({ success: true, count: enriched.length, issues: enriched });
  } catch (err) {
    logError('searchIssues', err);
    return res.status(500).json({ success: false, message: 'Failed to search issues', error: err.message });
  }
}

// Update state only (admins). Reporter cannot force a state change via this endpoint.
async function updateState(req, res) {
  try {
    const { id, newState } = req.body;
    if (!id || !newState) return res.status(400).json({ success: false, message: 'id and newState required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    if (issue.state !== newState) {
      const prev = issue.state;
      issue.state = newState;
      issue.stateHistory.push({ from: prev, to: newState, changedBy: req.user.attuid });
      if (newState === 'Resolved' && !issue.resolvedAt) issue.resolvedAt = new Date();
    }
    await issue.save();
    await publishNotification({ attuid: issue.reporter, title: 'Issue Status Updated', body: `Your issue (${issue.summary}) is now ${issue.state}.` });
  logSuccess('updateState', 'state changed', {
    issueId: issue._id,
    state: issue.state,
    actor: req.user.attuid,
    role: req.user.role,
    resolved: !!issue.resolvedAt,
    stateHistory: issue.stateHistory.length
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('updateState', err);
    return res.status(500).json({ success: false, message: 'Failed to update state', error: err.message });
  }
}

// Assign resolver (admin)
async function assignResolver(req, res) {
  try {
    const { id, resolver } = req.body;
    if (!id || !resolver) return res.status(400).json({ success: false, message: 'id and resolver required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    issue.resolver = resolver;
    await issue.save();
    await publishNotification({ attuid: issue.reporter, title: 'Issue Assigned', body: `Your issue (${issue.summary}) has been assigned.` });
  logSuccess('assignResolver', 'resolver assigned', {
    issueId: issue._id,
    resolver,
    actor: req.user.attuid,
    role: req.user.role
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('assignResolver', err);
    return res.status(500).json({ success: false, message: 'Failed to assign resolver', error: err.message });
  }
}

// Add resolution text (admin)
async function addResolution(req, res) {
  try {
    const { id, resolution } = req.body;
    if (!id || !resolution) return res.status(400).json({ success: false, message: 'id and resolution required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    issue.resolution = resolution.trim();
    if (issue.state === 'Resolved' && !issue.resolvedAt) issue.resolvedAt = new Date();
    await issue.save();
    await publishNotification({ attuid: issue.reporter, title: 'Issue Resolution Added', body: `A resolution was added to: ${issue.summary}` });
  logSuccess('addResolution', 'resolution added', {
    issueId: issue._id,
    actor: req.user.attuid,
    role: req.user.role,
    state: issue.state
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('addResolution', err);
    return res.status(500).json({ success: false, message: 'Failed to add resolution', error: err.message });
  }
}

// Reopen issue (reporter if Closed/Resolved/Rejected; admin always)
async function reopenIssue(req, res) {
  try {
    const { id } = req.body;
    if (!id) return res.status(400).json({ success: false, message: 'id required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    const allowed = ['Resolved','Closed','Rejected'];
    const isReporter = issue.reporter === req.user.attuid;
    const isAdmin = req.user.role === 'Administrator';
    if (!isAdmin && !(isReporter && allowed.includes(issue.state))) {
      return res.status(403).json({ success: false, message: 'Forbidden' });
    }
    if (issue.state !== 'Open') {
      const prev = issue.state;
      issue.state = 'Open';
      issue.stateHistory.push({ from: prev, to: 'Open', changedBy: req.user.attuid });
    }
    await issue.save();
    await publishNotification({ attuid: issue.reporter, title: 'Issue Reopened', body: `${issue.summary} reopened.` });
  logSuccess('reopenIssue', 'issue reopened', {
    issueId: issue._id,
    actor: req.user.attuid,
    role: req.user.role,
    stateHistory: issue.stateHistory.length
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('reopenIssue', err);
    return res.status(500).json({ success: false, message: 'Failed to reopen issue', error: err.message });
  }
}

// List comments
async function listComments(req, res) {
  try {
    const { id } = req.body;
    if (!id) return res.status(400).json({ success: false, message: 'id required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id, { comments: 1, reporter: 1, summary: 1 });
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    const isReporter = issue.reporter === req.user.attuid;
    const isAdmin = req.user.role === 'Administrator';
    if (!isReporter && !isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });
  logSuccess('listComments', 'comments listed', {
    issueId: issue._id,
    viewer: req.user.attuid,
    role: req.user.role,
    comments: issue.comments.length
  });
    return res.json({ success: true, count: issue.comments.length, comments: issue.comments });
  } catch (err) {
    logError('listComments', err);
    return res.status(500).json({ success: false, message: 'Failed to list comments', error: err.message });
  }
}

// Delete comment (admin only for now)
async function deleteComment(req, res) {
  try {
    const { id, commentId } = req.body;
    if (!id || !commentId) return res.status(400).json({ success: false, message: 'id and commentId required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    const before = issue.comments.length;
    issue.comments = issue.comments.filter(c => c._id.toString() !== commentId);
    if (issue.comments.length === before) return res.status(404).json({ success: false, message: 'Comment not found' });
    await issue.save();
  logSuccess('deleteComment', 'comment deleted', {
    issueId: issue._id,
    commentId,
    actor: req.user.attuid,
    role: req.user.role,
    remaining: issue.comments.length
  });
  return res.json({ success: true, issue, meta: buildIssueMeta(issue, req.user) });
  } catch (err) {
    logError('deleteComment', err);
    return res.status(500).json({ success: false, message: 'Failed to delete comment', error: err.message });
  }
}

// Add attachment metadata (no file storage logic here)
async function addAttachment(req, res) {
  try {
    const { id, filename, url } = req.body;
    if (!id || !filename || !url) return res.status(400).json({ success: false, message: 'id, filename, url required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    const isReporter = issue.reporter === req.user.attuid;
    const isAdmin = req.user.role === 'Administrator';
    if (!isReporter && !isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });
    issue.attachments.push({ filename, url, uploadedBy: req.user.attuid });
    await issue.save();
  logSuccess('addAttachment', 'attachment added', {
    issueId: issue._id,
    filename,
    actor: req.user.attuid,
    role: req.user.role,
    attachments: issue.attachments.length
  });
    return res.json({ success: true, issue });
  } catch (err) {
    logError('addAttachment', err);
    return res.status(500).json({ success: false, message: 'Failed to add attachment', error: err.message });
  }
}

// Remove attachment (admin or uploader)
async function removeAttachment(req, res) {
  try {
    const { id, attachmentId } = req.body;
    if (!id || !attachmentId) return res.status(400).json({ success: false, message: 'id and attachmentId required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id);
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    const isAdmin = req.user.role === 'Administrator';
    const attachment = issue.attachments.find(a => a._id.toString() === attachmentId);
    if (!attachment) return res.status(404).json({ success: false, message: 'Attachment not found' });
    if (!isAdmin && attachment.uploadedBy !== req.user.attuid) return res.status(403).json({ success: false, message: 'Forbidden' });
    issue.attachments = issue.attachments.filter(a => a._id.toString() !== attachmentId);
    await issue.save();
  logSuccess('removeAttachment', 'attachment removed', {
    issueId: issue._id,
    attachmentId,
    actor: req.user.attuid,
    role: req.user.role,
    remaining: issue.attachments.length
  });
    return res.json({ success: true, issue });
  } catch (err) {
    logError('removeAttachment', err);
    return res.status(500).json({ success: false, message: 'Failed to remove attachment', error: err.message });
  }
}

// Stats (admins only) simple aggregations
async function stats(req, res) {
  try {
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const byState = await Issue.aggregate([{ $group: { _id: '$state', count: { $sum: 1 } } }]);
    const bySeverity = await Issue.aggregate([{ $group: { _id: '$severity', count: { $sum: 1 } } }]);
    const openCount = await Issue.countDocuments({ state: { $in: ['Open','In Progress','Awaiting Info'] } });
  logSuccess('stats', 'stats computed', {
    uniqueStates: byState.length,
    uniqueSeverities: bySeverity.length,
    openActive: openCount
  });
    return res.json({ success: true, byState, bySeverity, openCount });
  } catch (err) {
    logError('stats', err);
    return res.status(500).json({ success: false, message: 'Failed to compute stats', error: err.message });
  }
}

// Export (admins) returns minimal dataset
async function exportIssues(req, res) {
  try {
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const { states } = req.body;
    const filter = states && Array.isArray(states) && states.length ? { state: { $in: states } } : {};
    const issues = await Issue.find(filter).lean();
    // Keep lightweight fields
    const exportData = issues.map(i => ({
      id: i._id,
      summary: i.summary,
      state: i.state,
      severity: i.severity,
      impact: i.impact,
      reporter: i.reporter,
      createdAt: i.createdAt,
      resolvedAt: i.resolvedAt
    }));
  logSuccess('exportIssues', 'issues exported', {
    count: exportData.length,
    statesFiltered: (req.body.states && req.body.states.length) ? 'yes' : 'no'
  });
    return res.json({ success: true, count: exportData.length, issues: exportData });
  } catch (err) {
    logError('exportIssues', err);
    return res.status(500).json({ success: false, message: 'Failed to export issues', error: err.message });
  }
}

// Timeline (state history + comments chronologically)
async function timeline(req, res) {
  try {
    const { id } = req.body;
    if (!id) return res.status(400).json({ success: false, message: 'id required' });
    if (!Types.ObjectId.isValid(id)) return res.status(400).json({ success: false, message: 'Invalid issue id format' });
    const issue = await Issue.findById(id).lean();
    if (!issue) return res.status(404).json({ success: false, message: 'Issue not found' });
    const isReporter = issue.reporter === req.user.attuid;
    const isAdmin = req.user.role === 'Administrator';
    if (!isReporter && !isAdmin) return res.status(403).json({ success: false, message: 'Forbidden' });
    const events = [];
    issue.stateHistory.forEach(h => events.push({ type: 'state', from: h.from, to: h.to, by: h.changedBy, at: h.changedAt }));
    issue.comments.forEach(c => events.push({ type: 'comment', author: c.author, text: c.text, at: c.created }));
    events.sort((a,b) => new Date(a.at) - new Date(b.at));
  logSuccess('timeline', 'timeline built', {
    issueId: issue._id,
    events: events.length,
    transitions: issue.stateHistory.length,
    comments: issue.comments.length
  });
    return res.json({ success: true, issueId: issue._id, events });
  } catch (err) {
    logError('timeline', err);
    return res.status(500).json({ success: false, message: 'Failed to build timeline', error: err.message });
  }
}

// Bulk update state (admin)
async function bulkUpdateState(req, res) {
  try {
    const { ids, newState } = req.body;
    if (!Array.isArray(ids) || !ids.length || !newState) return res.status(400).json({ success: false, message: 'ids[] and newState required' });
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const issues = await Issue.find({ _id: { $in: ids } });
    let updated = 0;
    for (const issue of issues) {
      if (issue.state !== newState) {
        const prev = issue.state;
        issue.state = newState;
        issue.stateHistory.push({ from: prev, to: newState, changedBy: req.user.attuid });
        if (newState === 'Resolved' && !issue.resolvedAt) issue.resolvedAt = new Date();
        await issue.save();
        updated++;
        await publishNotification({ attuid: issue.reporter, title: 'Issue Status Updated', body: `${issue.summary} now ${issue.state}` });
      }
    }
  logSuccess('bulkUpdateState', 'bulk state update', {
    requested: ids.length,
    updated,
    state: newState
  });
    return res.json({ success: true, requested: ids.length, updated });
  } catch (err) {
    logError('bulkUpdateState', err);
    return res.status(500).json({ success: false, message: 'Failed to bulk update state', error: err.message });
  }
}

// Bulk delete (admin)
async function bulkDelete(req, res) {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || !ids.length) return res.status(400).json({ success: false, message: 'ids[] required' });
    if (req.user.role !== 'Administrator') return res.status(403).json({ success: false, message: 'Forbidden' });
    const result = await Issue.deleteMany({ _id: { $in: ids } });
  logSuccess('bulkDelete', 'bulk delete', {
    requested: ids.length,
    deleted: result.deletedCount
  });
    return res.json({ success: true, deleted: result.deletedCount });
  } catch (err) {
    logError('bulkDelete', err);
    return res.status(500).json({ success: false, message: 'Failed to bulk delete', error: err.message });
  }
}

// Reference lists (POST endpoints returning static enumerations)
function listStates(req, res) {
  logSuccess('listStates', 'states listed');
  return res.json({ success: true, states: ['Open','In Progress','Awaiting Info','Resolved','Closed','Rejected'] });
}
function listSeverities(req, res) {
  logSuccess('listSeverities', 'severities listed');
  return res.json({ success: true, severities: ['Minor','Moderate','Major','Critical'] });
}
function listImpacts(req, res) {
  logSuccess('listImpacts', 'impacts listed');
  return res.json({ success: true, impacts: ['Single User','Team','Department / Floor','Entire Site'] });
}

module.exports = { 
  authMiddleware, adminOnly,
  // core
  createIssue, fetchIssue, fetchAllIssues, updateIssue, addComment, deleteIssue,
  // additional
  fetchMyIssues, fetchByState, searchIssues, updateState, assignResolver, addResolution, reopenIssue,
  listComments, deleteComment, addAttachment, removeAttachment, stats, exportIssues, timeline,
  bulkUpdateState, bulkDelete, listStates, listSeverities, listImpacts
};