const express = require('express');
const router = express.Router();
const c = require('../controllers/issueController');

// Base segment: /issue-reported/* (all POST only as requested)
router.post('/issue-reported/create-issue', c.authMiddleware, c.createIssue);
router.post('/issue-reported/fetch-issue', c.authMiddleware, c.fetchIssue);
router.post('/issue-reported/fetch-all-issue', c.authMiddleware, c.fetchAllIssues);
router.post('/issue-reported/fetch-my-issues', c.authMiddleware, c.fetchMyIssues);
router.post('/issue-reported/fetch-by-state', c.authMiddleware, c.fetchByState);
router.post('/issue-reported/search', c.authMiddleware, c.searchIssues);
router.post('/issue-reported/update-issue', c.authMiddleware, c.updateIssue);
router.post('/issue-reported/update-state', c.authMiddleware, c.adminOnly, c.updateState);
router.post('/issue-reported/assign-resolver', c.authMiddleware, c.adminOnly, c.assignResolver);
router.post('/issue-reported/add-resolution', c.authMiddleware, c.adminOnly, c.addResolution);
router.post('/issue-reported/reopen-issue', c.authMiddleware, c.reopenIssue);
router.post('/issue-reported/add-comment', c.authMiddleware, c.addComment);
router.post('/issue-reported/list-comments', c.authMiddleware, c.listComments);
router.post('/issue-reported/delete-comment', c.authMiddleware, c.adminOnly, c.deleteComment);
router.post('/issue-reported/add-attachment', c.authMiddleware, c.addAttachment);
router.post('/issue-reported/remove-attachment', c.authMiddleware, c.removeAttachment);
router.post('/issue-reported/delete-issue', c.authMiddleware, c.adminOnly, c.deleteIssue);
router.post('/issue-reported/stats', c.authMiddleware, c.adminOnly, c.stats);
router.post('/issue-reported/export', c.authMiddleware, c.adminOnly, c.exportIssues);
router.post('/issue-reported/timeline', c.authMiddleware, c.timeline);
router.post('/issue-reported/bulk-update-state', c.authMiddleware, c.adminOnly, c.bulkUpdateState);
router.post('/issue-reported/bulk-delete', c.authMiddleware, c.adminOnly, c.bulkDelete);

// Enumerations (still POST to comply with "no GET")
router.post('/issue-reported/list-states', c.authMiddleware, c.listStates);
router.post('/issue-reported/list-severities', c.authMiddleware, c.listSeverities);
router.post('/issue-reported/list-impacts', c.authMiddleware, c.listImpacts);

module.exports = router;