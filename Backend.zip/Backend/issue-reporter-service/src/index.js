const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const cors = require('cors');
const mongoose = require('mongoose');

const { mongoUri, mongoDb, port, corsOrigin } = require('./config');
const logger = require('./utils/logger');
const issueRoutes = require('./routes/issueRoutes');

let appInstance = null;
async function start() {
  try {
    if (!appInstance) {
      logger.info('Starting issue-reporter service...');
      await mongoose.connect(`${mongoUri}/${mongoDb}`, { useNewUrlParser: true, useUnifiedTopology: true });
      logger.info('Connected to MongoDB');

      const app = express();
      app.use(express.json());
      app.use(cookieParser());

      app.use(cors({
        origin: corsOrigin,
        methods: ['GET','POST','PUT','DELETE'],
        credentials: true
      }));

      app.use(helmet());
      app.use(bodyParser.json());

      app.use('/', issueRoutes);
      app.get('/', (req, res) => res.json({ service: 'issue-reporter-service', status: 'ok' }));
      appInstance = app;
      if (process.env.NODE_ENV !== 'test') {
        app.listen(port, () => logger.info(`Issue-reporter service listening on port ${port}`));
      }
    }
    return appInstance;
  } catch (err) {
    logger.error('Failed to start service: ' + err.toString());
    if (process.env.NODE_ENV !== 'test') process.exit(1);
    throw err;
  }
}

// Auto-start outside test
if (process.env.NODE_ENV !== 'test') {
  start();
}

module.exports = { start };