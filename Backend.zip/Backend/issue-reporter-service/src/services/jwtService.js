const jwt = require('jsonwebtoken');
const { jwtSecret, jwtExpiresIn } = require('../config');

function verify(token) { return jwt.verify(token, jwtSecret); }
function sign(payload) { return jwt.sign(payload, jwtSecret, { expiresIn: jwtExpiresIn }); }

module.exports = { verify, sign };