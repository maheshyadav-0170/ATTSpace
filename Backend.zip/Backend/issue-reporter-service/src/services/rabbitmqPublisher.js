const amqplib = require('amqplib');
const { rabbitmqUrl } = require('../config');
const logger = require('../utils/logger');

let channel = null;

async function initRabbit() {
  if (channel) return channel;
  const conn = await amqplib.connect(rabbitmqUrl);
  channel = await conn.createChannel();
  await channel.assertQueue('send_notification', { durable: true });
  logger.info('RabbitMQ channel ready (issue-reporter)');
  return channel;
}

async function publishNotification(message) {
  try {
    await initRabbit();
    const buffer = Buffer.from(JSON.stringify(message));
    channel.sendToQueue('send_notification', buffer, { persistent: true });
    logger.info(`Notification queued: ${JSON.stringify(message)}`);
  } catch (err) {
    logger.error('publishNotification error: ' + err.message);
  }
}

module.exports = { publishNotification, initRabbit };