const { createClient } = require('redis');
const { redisHost, redisPort } = require('../config');
const logger = require('../utils/logger');

const redisClient = createClient({ socket: { host: redisHost, port: redisPort } });
redisClient.on('error', (err) => logger.error('Redis error: ' + err.toString()));

async function initRedis() {
  if (!redisClient.isOpen) await redisClient.connect();
}

module.exports = { initRedis, redisClient };