// WebSocket server for notification-service
const WebSocket = require('ws');
let wss;
let wsClients = [];

function setupWebSocketServer(server) {
  wss = new WebSocket.Server({ server });
  wss.on('connection', (ws) => {
    wsClients.push(ws);
    ws.on('close', () => {
      wsClients = wsClients.filter((c) => c !== ws);
    });
  });
}

function broadcastNotification(notification) {
  const data = JSON.stringify(notification);
  wsClients.forEach((ws) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(data);
    }
  });
}

module.exports = { setupWebSocketServer, broadcastNotification };