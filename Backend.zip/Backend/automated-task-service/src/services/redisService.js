// redisService.js
const { createClient } = require('redis');
const logger = require('../utils/logger');

const redisHost = process.env.REDIS_HOST || 'localhost';
const redisPort = process.env.REDIS_PORT || 6379;

const redisClient = createClient({ socket: { host: redisHost, port: redisPort } });
redisClient.on('error', (err) => logger.error('Redis error: ' + err.toString()));

async function initRedis() {
  if (!redisClient.isOpen) {
    await redisClient.connect();
    logger.info(`Connected to Redis at ${redisHost}:${redisPort}`);
  }
}

module.exports = {
  redisClient,
  initRedis,
};
