// rabbitmqService.js
const amqplib = require('amqplib');
const logger = require('../utils/logger');

const RABBITMQ_URL = process.env.RABBITMQ_URL || 'amqp://rabbitmq';
const QUEUE = 'send_notification';

async function sendNotification(msg) {
  let conn, ch;
  try {
    conn = await amqplib.connect(RABBITMQ_URL);
    ch = await conn.createChannel();
    await ch.assertQueue(QUEUE, { durable: true });
    ch.sendToQueue(QUEUE, Buffer.from(JSON.stringify(msg)), { persistent: true });
    logger.info(`✅ Notification sent to queue: ${QUEUE}`);
    setTimeout(async () => {
      try {
        await ch.close();
        await conn.close();
      } catch (err) {
        logger.error('Error closing RabbitMQ connection: ' + err);
      }
    }, 500);
  } catch (err) {
    logger.error('Error sending notification via RabbitMQ: ' + err);
    if (conn) {
      try { await conn.close(); } catch (e) { logger.error('Error closing RabbitMQ conn after error: ' + e); }
    }
  }
}

module.exports = {
  sendNotification,
};
