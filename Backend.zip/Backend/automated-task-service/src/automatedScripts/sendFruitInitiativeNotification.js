const amqplib = require("amqplib");
const redis = require("redis");

// Use Docker service name for Redis connection
const REDIS_URL = process.env.REDIS_URL || "redis://redis:6379";
const RABBITMQ_URL = process.env.RABBITMQ_URL || "amqp://rabbitmq";
const QUEUE = "send_notification";
const AUTH_USERS_KEY = "all_authusers";

async function sendFruitInitiativeNotifications() {

  const redisClient = redis.createClient({ url: REDIS_URL });
  try {
    await redisClient.connect();
    let usersRaw = await redisClient.get(AUTH_USERS_KEY);
    if (!usersRaw) {
      console.error("No auth users found in Redis.");
      await redisClient.quit();
      return;
    }

    let users;
    try {
      users = JSON.parse(usersRaw);
    } catch (err) {
      console.error("Error parsing users from Redis:", err);
      await redisClient.quit();
      return;
    }

    const conn = await amqplib.connect(RABBITMQ_URL);
    const ch = await conn.createChannel();
    await ch.assertQueue(QUEUE, { durable: true });

    const msgTemplate = {
      title: "Fresh Fruit Initiative 🍎🍌🍊",
      body:
        "We're thrilled to introduce Fresh Fruit Initiative for employees! Starting from 1st July 2025, fresh fruits will be available at 10th & 11th floor cafeteria. This new initiative aims to promote a healthy and energized work environment. We believe that taking care of our well-being is essential.",
    };

    for (const user of users) {
      const msg = {
        attuid: user.attuid,
        ...msgTemplate,
      };
      ch.sendToQueue(QUEUE, Buffer.from(JSON.stringify(msg)), { persistent: true });
      console.log(`✅ Fruit Initiative notification sent to ${user.attuid}`);
    }

    setTimeout(async () => {
      await ch.close();
      await conn.close();
      await redisClient.quit();
      process.exit(0);
    }, 500);
  } catch (err) {
    console.error("Error in Fruit Initiative notification script:", err);
    try { await redisClient.quit(); } catch {}
  }
}

if (require.main === module) {
  sendFruitInitiativeNotifications();
}
