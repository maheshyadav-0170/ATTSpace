const axios = require('axios');
const logger = require("../utils/logger");
const { redisClient, initRedis } = require("../services/redisService");
const { sendNotification } = require("../services/rabbitmqService");

const AUTH_USERS_KEY = "all_authusers";

// AI API credentials and endpoints
const client_id = 'd6bd936f-5dfb-41d8-84a3-fe2191e3ba50';
const client_secret = 'B1H8Q~i5NRWR5WbNFRutgIOrYn8.TXRWgJxWJcAO';
const auth_url = 'https://login.microsoftonline.com/e741d71c-c6b6-47b0-803c-0f3b32b07556/oauth2/v2.0/token';
const scope = 'api://95273ce2-6fec-4001-9716-a209d398184f/.default';
const grant_type = 'client_credentials';
const ai_url = "https://askattapis-orchestration-stage.dev.att.com/api/v1/askatt/question";

async function getAccessToken() {
  const payload = new URLSearchParams({
    client_id,
    client_secret,
    scope,
    grant_type
  });
  try {
    const response = await axios.post(auth_url, payload);
    return response.data.access_token;
  } catch (err) {
    logger.error("Error obtaining JWT token: " + err);
    throw err;
  }
}

async function getAIFruitMessage(user) {
  const access_token = await getAccessToken();
  // Check Redis for seasonalFruit key
  let fruit = null;
  try {
    fruit = await redisClient.get("seasonalFruit");
    if (fruit) fruit = fruit.trim();
  } catch (err) {
    logger.warn("Could not fetch seasonalFruit from Redis: " + err);
  }
  let prompt;
  if (!fruit) {
    prompt = `Generate a unique, friendly notification for employee ${user.attuid} about fruit being available in the cafeteria this week. Do not mention any specific fruit names, just refer to 'fruit'. Return a JSON with title and body.`;
  } else {
    prompt = `Generate a unique, friendly notification for employee ${user.attuid} about ${fruit} being available in the cafeteria this week. Make it fun and ${fruit}-themed. Return a JSON with title and body.`;
  }
  const payload = {
    domainName: "GenerativeAI",
    modelName: "gpt-4.1-mini",
    modelVersion: "2025-01-01-preview",
    modelPayload: {
      messages: [
        { role: "system", content: "You are a personal assistant" },
        { role: "user", content: prompt }
      ],
      temperature: 0.85,
      top_p: 0.95,
      frequency_penalty: 0,
      presence_penalty: 0,
      max_tokens: 2000,
      stop: null
    }
  };
  try {
    const response = await axios.post(ai_url, payload, {
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json'
      }
    });
    // Parse AI response
    let aiMsg = response.data?.modelResult?.choices?.[0]?.message?.content;
    let title = "Seasonal Fruits Alert";
    let body = aiMsg;
    // Remove Markdown code block formatting if present
    if (typeof aiMsg === "string") {
      // Remove triple backticks and optional language
      aiMsg = aiMsg.replace(/^```[a-zA-Z]*\n/, "").replace(/```$/, "").trim();
    }
    // Try to parse JSON if AI returns it
    try {
      const parsed = JSON.parse(aiMsg);
      title = parsed.title || title;
      body = parsed.body || body;
    } catch {}
    return { title, body };
  } catch (err) {
    logger.error("Error from AI API: " + err);
    return {
      title: fruit ? `${fruit} Available in Cafeteria!` : "Seasonal Fruits Available 🍎🍌🍊",
      body: fruit ? `Enjoy fresh ${fruit} at the cafeteria this week! Take a healthy break and energize your day!` : "Enjoy fresh seasonal fruits at the cafeteria! Take a healthy break and energize your day!"
    };
  }
}

async function sendAIFruitNotifications() {
  try {
    await initRedis();
    let usersRaw = await redisClient.get(AUTH_USERS_KEY);
    if (!usersRaw) {
      logger.warn("No auth users found in Redis.");
      return;
    }
    let users;
    try {
      users = JSON.parse(usersRaw);
    } catch (err) {
      logger.error("Error parsing users from Redis: " + err);
      return;
    }
    for (const user of users) {
      const aiMsg = await getAIFruitMessage(user);
      const msg = {
        attuid: user.attuid,
        ...aiMsg,
      };
      await sendNotification(msg);
      logger.info(`✅ AI Fruit notification sent to ${user.attuid}`);
    }
    if (redisClient.isOpen) {
      await redisClient.quit();
      logger.info("Redis connection closed");
    }
  } catch (err) {
    logger.error("Error in sendAIFruitNotifications: " + err);
    if (redisClient.isOpen) {
      await redisClient.quit();
      logger.info("Redis connection closed after error");
    }
  }
}

if (require.main === module) {
  sendAIFruitNotifications();
}

module.exports = { sendAIFruitNotifications };
