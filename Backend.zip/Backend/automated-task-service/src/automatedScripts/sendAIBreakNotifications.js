
const axios = require("axios");
const logger = require("../utils/logger");
const { redisClient, initRedis } = require("../services/redisService");
const { sendNotification } = require("../services/rabbitmqService");
const { v4: uuidv4 } = require("uuid");

const AUTH_USERS_KEY = "all_authusers";

// AI API credentials and endpoints
const client_id = 'd6bd936f-5dfb-41d8-84a3-fe2191e3ba50';
const client_secret = 'B1H8Q~i5NRWR5WbNFRutgIOrYn8.TXRWgJxWJcAO';
const auth_url = 'https://login.microsoftonline.com/e741d71c-c6b6-47b0-803c-0f3b32b07556/oauth2/v2.0/token';
const scope = 'api://95273ce2-6fec-4001-9716-a209d398184f/.default';
const grant_type = 'client_credentials';
const ai_url = "https://askattapis-orchestration-stage.dev.att.com/api/v1/askatt/question";


async function getAccessToken() {
  const payload = new URLSearchParams({
    client_id,
    client_secret,
    scope,
    grant_type
  });
  try {
    const response = await axios.post(auth_url, payload);
    return response.data.access_token;
  } catch (err) {
    logger.error("Error obtaining JWT token: " + err);
    throw err;
  }
}

async function getAIWellnessMessage(user) {
  const access_token = await getAccessToken();
  const name = user.firstname ? `${user.firstname} ${user.lastname || ''}`.trim() : user.attuid;
  const prompt = `Generate a unique, motivating notification for employee ${name} about taking a wellness break. Make both the "title" and "body" fields creative and engaging. Return a JSON object with "title" (max 8 words, catchy) and "body" (1-2 sentences, supportive). Example: {"title": "Time to Recharge!", "body": "Hi Alex, take a break to refresh your mind and body."}`;
  const payload = {
    domainName: "GenerativeAI",
    modelName: "gpt-4.1-mini",
    modelVersion: "2025-01-01-preview",
    modelPayload: {
      messages: [
        { role: "system", content: "You are a personal assistant" },
        { role: "user", content: prompt }
      ],
      temperature: 0.85,
      top_p: 0.95,
      frequency_penalty: 0,
      presence_penalty: 0,
      max_tokens: 2000,
      stop: null
    }
  };
  try {
    const response = await axios.post(ai_url, payload, {
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json'
      }
    });
    let aiMsg = response.data?.modelResult?.choices?.[0]?.message?.content;
    let title = "Wellness Break Reminder";
    let body = aiMsg;
    if (typeof aiMsg === "string") {
      aiMsg = aiMsg.replace(/^```[a-zA-Z]*\n/, "").replace(/```$/, "").trim();
    }
    try {
      const parsed = JSON.parse(aiMsg);
      title = parsed.title || title;
      body = parsed.body || body;
    } catch {}
    return { title, body };
  } catch (err) {
    logger.error("Error from AI API: " + err);
    return {
      title: "Wellness Break Reminder",
      body: `Hi ${user.firstname}, it's time for a wellness break! Stretch, hydrate, and refresh your mind.`
    };
  }
}

function getLoginWindow(now) {
  const jobMinutes = now.getHours() * 60 + now.getMinutes();
  const slotIndex = Math.floor((jobMinutes - 570) / 30); // 570 = 9*60
  const startMinutes = 570 + slotIndex * 30;
  const endMinutes = startMinutes + 30;
  const pad = (n) => n.toString().padStart(2, "0");
  return [
    `${pad(Math.floor(startMinutes / 60))}:${pad(startMinutes % 60)}`,
    `${pad(Math.floor(endMinutes / 60))}:${pad(endMinutes % 60)}`,
  ];
}

function parseShiftStart(shift) {
  if (!shift) return null;
  const match = shift.match(/^(\d{1,2}:\d{2})/);
  return match ? match[1] : null;
}

async function sendAIWellnessNotifications() {
  try {
    await initRedis();
    const now = new Date();
    const istNow = new Date(now.getTime() + 5.5 * 60 * 60 * 1000);
    const istMinus3hr = new Date(istNow.getTime() - 3 * 60 * 60 * 1000);
    const [loginStart, loginEnd] = getLoginWindow(istMinus3hr);

    let usersRaw = await redisClient.get(AUTH_USERS_KEY);
    if (!usersRaw) {
      logger.warn("No auth users found in Redis.");
      return;
    }
    let users;
    try {
      users = JSON.parse(usersRaw);
    } catch (err) {
      logger.error("Error parsing users from Redis: " + err);
      return;
    }
    const eligibleUsers = users.filter((user) => {
      const shiftStart = parseShiftStart(user.shift);
      return (
        shiftStart &&
        shiftStart >= loginStart &&
        shiftStart < loginEnd
      );
    });
    if (eligibleUsers.length === 0) {
      logger.info(`No users found for login window ${loginStart} to ${loginEnd} IST.`);
      return;
    }
    for (const user of eligibleUsers) {
      const aiMsg = await getAIWellnessMessage(user);
      const msg = {
        attuid: user.attuid,
        ...aiMsg,
        notificationId: uuidv4(),
        timestamp: new Date().toISOString(),
      };
      await sendNotification(msg);
      logger.info(`✅ AI Wellness break notification sent to ${user.attuid} (${user.firstname}) for shift ${user.shift} | Title: ${aiMsg.title}`);
    }
    if (redisClient.isOpen) {
      await redisClient.quit();
      logger.info("Redis connection closed");
    }
    process.exit(0);
  } catch (err) {
    logger.error("Error in sendAIWellnessNotifications: " + err);
    if (redisClient.isOpen) {
      await redisClient.quit();
      logger.info("Redis connection closed after error");
    }
  }
}


module.exports = { sendAIWellnessNotifications };
