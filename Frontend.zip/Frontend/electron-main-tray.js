import { app, BrowserWindow, ipcMain, Tray, Notification, Menu } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import WebSocket from 'ws';
import { exec } from 'child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));


let tray = null;
let win = null;
let ws = null;
let currentAttuid = null;
// Listen for attuid from renderer
ipcMain.on('set-attuid', (event, attuid) => {
  currentAttuid = attuid;
});

function createWindow() {
  win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });
  win.loadURL('http://localhost:5173');
  win.on('close', (event) => {
    event.preventDefault();
    win.hide();
  });
}

function setupWebSocket() {
  ws = new WebSocket('ws://localhost:4001');
  ws.on('message', (data) => {
    try {
      const notif = JSON.parse(data);
      if (!notif.attuid || notif.attuid === currentAttuid) {
        new Notification({ title: notif.title, body: notif.body }).show();
      }
    } catch {}
  });
  ws.on('close', () => {
    setTimeout(setupWebSocket, 5000);
  });
  ws.on('error', () => {
    setTimeout(setupWebSocket, 5000);
  });
}

ipcMain.handle('run-ipconfig', async () => {
  return new Promise((resolve) => {
    exec('ipconfig', (error, stdout, stderr) => {
      if (error) {
        resolve(stderr || error.message);
        return;
      }
      resolve(stdout);
    });
  });
});

app.whenReady().then(() => {
  // Remove global application menu so File/Edit menu doesn't show
  // try {
  //   Menu.setApplicationMenu(null);
  // } catch (e) {}

  createWindow();
  tray = new Tray(path.join(__dirname, 'icon.png'));
  tray.setToolTip('ATTSpace');
  tray.on('click', () => {
    if (!win) {
      createWindow();
      return;
    }
    if (win.isMinimized()) win.restore();
    win.show();
    win.focus();
  });
  setupWebSocket();
});

app.on('window-all-closed', (e) => {
  e.preventDefault();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
