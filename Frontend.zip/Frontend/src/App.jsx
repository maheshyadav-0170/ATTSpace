import { useEffect } from 'react';
import React, { useState } from 'react';
import './App.css';
import Header from './Components/Header';
import HeroSection from './Components/HeroSection';
import AboutSection from './Components/AboutSection';
import FeaturesSection from './Components/FeaturesSection';
import BenefitsSection from './Components/BenefitsSection';
import HowItWorksSection from './Components/HowItWorksSection';
import StatsSection from './Components/StatsSection';
import ServicesSection from './Components/ServicesSection';
import TestimonialsSection from './Components/TestimonialsSection';
import FAQSection from './Components/FAQSection';
import ContactSection from './Components/ContactSection';
import FooterSection from './Components/FooterSection';
import HomePage from './Components/HomePage';
import ReserveDesk from './Components/ReserveDesk';


function App() {
  const [showForm, setShowForm] = useState(false);
  const handleGetStarted = (e) => {
    if (e) e.preventDefault();
    setShowForm(true);
  };
  // New: handle reset to image
  const handleShowHome = () => setShowForm(false);
  useEffect(() => {
    // On mount, scroll to home section
    const homeSection = document.getElementById('home');
    if (homeSection) {
      homeSection.scrollIntoView({ behavior: 'auto', block: 'start' });
    }
  }, []);
  return (
    <div className="site-wrap">
      <Header handleGetStarted={handleGetStarted} handleShowHome={handleShowHome} />
      <main>
        <HeroSection showForm={showForm} handleGetStarted={handleGetStarted} />
        <AboutSection />
        <FeaturesSection />
        <BenefitsSection />
        <HowItWorksSection />
        <StatsSection />
        <ServicesSection />
        <TestimonialsSection />
        <FAQSection />
        <ContactSection />
        {/* <HomePage /> */}
        {/* <div style={{position:'relative', left:'50%', transform:'translateX(-50%)', width:'100vw', maxWidth:'100vw', margin:0, padding:0, marginBottom:0}}>
          <ReserveDesk />
        </div>
        <div style={{marginTop:0, paddingTop:0}}>
          <FooterSection />
        </div> */}
        {/* <HowItWorksSection /> */}
  {/* FooterSection moved above with no margin for ReserveDesk */}
      </main>
    </div>
  );
}

export default App;
