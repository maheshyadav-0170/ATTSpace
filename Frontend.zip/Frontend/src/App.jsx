import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import HomePage from './HomePage/HomePage';
import PlayRelax from './Playrelax/Playrelax';
import LandingPage from './LandingPage';
import ProtectedRoute from './ProtectedRoute';
import AssistantFab from './components/AssistantFab';
import FeedbackReporter from './components/FeedbackReporter';
import IssueReporter from './components/IssueReporter';
import FloorMapFab from './components/FloorMapFab';
import FloorMapModal from './components/FloorMapModal';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route
          path="/home"
          element={
            <ProtectedRoute>
              <HomePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/play-relax"
          element={
            <ProtectedRoute>
              <PlayRelax />
            </ProtectedRoute>
          }
        />
        <Route path="/reservation" element={<div>Reservation Page (Under Construction)</div>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    <AssistantFab />
    <FeedbackReporter />
    <IssueReporter />
    <FloorMapFab />
  <FloorMapModal />
    </Router>
  );
}

export default App;