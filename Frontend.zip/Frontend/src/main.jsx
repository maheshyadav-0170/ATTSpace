
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// Send attuid to main process as soon as possible
if (window.electronAPI && window.electronAPI.setAttuid) {
  const attuid = localStorage.getItem('attuid');
  if (attuid) window.electronAPI.setAttuid(attuid);
}

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
