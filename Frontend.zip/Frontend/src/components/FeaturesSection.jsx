import React from 'react';

const FeaturesSection = () => (
  <section className="section features__v2" id="features">
    <div className="container">
      <div className="row">
        <div className="col-12">
          <div className="d-lg-flex p-5 rounded-4 content" data-aos="fade-in" data-aos-delay="0">
            <div className="row">
              <div className="col-lg-5 mb-5 mb-lg-0" data-aos="fade-up" data-aos-delay="0">
                <div className="row"> 
                  <div className="col-lg-11">
                    <div className="h-100 flex-column justify-content-between d-flex">
                      <div>
                        <h2 className="mb-4">Why ATTSpace?</h2>
                        <p className="mb-5">Transform your AT&T workspace with a sophisticated platform that streamlines desk and meeting room reservations, fosters collaboration through gamified challenges, and promotes holistic employee well-being.</p>
                      </div>
                      <div className="align-self-start"><a className="glightbox btn btn-play d-inline-flex align-items-center gap-2" href="https://www.youtube.com/watch?v=DQx96G4yHd8" data-gallery="video"><i className="bi bi-play-fill"></i> Watch the Video</a></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-7">
                <div className="row justify-content-end">
                  <div className="col-lg-11">
                    <div className="row">
                      <div className="col-sm-6" data-aos="fade-up" data-aos-delay="0">
                        <div className="icon text-center mb-4"><i className="bi bi-calendar-check fs-4"></i></div>
                        <h3 className="fs-6 fw-bold mb-3">Smart Desk Reservation</h3>
                        <p>Effortlessly book desks and meeting rooms with shift-aware scheduling and real-time availability.</p>
                      </div>
                      <div className="col-sm-6" data-aos="fade-up" data-aos-delay="100">
                        <div className="icon text-center mb-4"><i className="bi bi-gear fs-4"></i></div>
                        <h3 className="fs-6 fw-bold mb-3">AI Space Allocation</h3>
                        <p>AI-driven categorization suggests low-density focus zones and auto-allocates desks based on usage.</p>
                      </div>
                      <div className="col-sm-6" data-aos="fade-up" data-aos-delay="200">
                        <div className="icon text-center mb-4"><i className="bi bi-bell fs-4"></i></div>
                        <h3 className="fs-6 fw-bold mb-3">Wellness Notifications</h3>
                        <p>Timely reminders for breaks, hydration, and seasonal fruit alerts to support employee health.</p>
                      </div>
                      <div className="col-sm-6" data-aos="fade-up" data-aos-delay="300">
                        <div className="icon text-center mb-4"><i className="bi bi-trophy fs-4"></i></div>
                        <h3 className="fs-6 fw-bold mb-3">TeamPlay Arena</h3>
                        <p>Engage in gamified team challenges like table tennis or carrom to foster collaboration.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default FeaturesSection;
