import React from 'react';

const HowItWorksSection = () => (
  <section className="section howitworks__v1" id="how-it-works">
    <div className="container Gurumukhi">
      <div className="row mb-5">
        <div className="col-md-6 text-center mx-auto">
          <span className="subtitle text-uppercase mb-3" data-aos="fade-up" data-aos-delay="0">How It Works</span>
          <h2 data-aos="fade-up" data-aos-delay="100">Get Started with ATTSpace</h2>
          <p data-aos="fade-up" data-aos-delay="200">Our advanced platform streamlines workspace management, enhances collaboration, and promotes holistic well-being for AT&T employees. Follow these steps to get started:</p>
        </div>
      </div>
      <div className="row g-md-5">
        <div className="col-md-6 col-lg-3">
          <div className="step-card text-center h-100 d-flex flex-column justify-content-start position-relative" data-aos="fade-up" data-aos-delay="0">
            <div data-aos="fade-right" data-aos-delay="500"><img className="arch-line" src="/assets/images/arch-line.svg" alt="ATTSpace step connector" /></div>
            <span className="step-number rounded-circle text-center fw-bold mb-5 mx-auto">1</span>
            <div>
              <h3 className="fs-5 mb-4">Log In</h3>
              <p>Access ATTSpace via the AT&T intranet or mobile app using your employee credentials for instant access.</p>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="600">
          <div className="step-card reverse text-center h-100 d-flex flex-column justify-content-start position-relative">
            <div data-aos="fade-right" data-aos-delay="1100"><img className="arch-line reverse" src="/assets/images/arch-line-reverse.svg" alt="ATTSpace step connector" /></div>
            <span className="step-number rounded-circle text-center fw-bold mb-5 mx-auto">2</span>
            <h3 className="fs-5 mb-4">Set Preferred Location</h3>
            <p>Select your preferred workspace location to tailor your booking experience to your needs.</p>
          </div>
        </div>
        <div className="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1200">
          <div className="step-card text-center h-100 d-flex flex-column justify-content-start position-relative">
            <div data-aos="fade-right" data-aos-delay="1700"><img className="arch-line" src="/assets/images/arch-line.svg" alt="ATTSpace step connector" /></div>
            <span className="step-number rounded-circle text-center fw-bold mb-5 mx-auto">3</span>
            <h3 className="fs-5 mb-4">Book Your Space</h3>
            <p>Reserve desks or meeting rooms effortlessly with AI-driven suggestions for optimal availability.</p>
          </div>
        </div>
        <div className="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1800">
          <div className="step-card last text-center h-100 d-flex flex-column justify-content-start position-relative">
            <span className="step-number rounded-circle text-center fw-bold mb-5 mx-auto">4</span>
            <div>
              <h3 className="fs-5 mb-4">Engage and Thrive</h3>
              <p>Join gamified team challenges like table tennis or carrom and receive wellness reminders to enhance your workplace experience.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default HowItWorksSection;
