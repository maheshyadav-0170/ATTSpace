import React from 'react';
import './AppFooter.css';

// variant: 'dark' | 'mid' | 'light'
const AppFooter = ({ version = 'v1.0.0', variant = 'mid' }) => {
  const year = new Date().getFullYear();
  return (
    <footer className={`app-footer app-footer--${variant}`} role="contentinfo">
      <div className="footer-inner">
        <div className="footer-top">
          <div className="footer-brand">
            <span className="product-name">ATTSpace</span>
            <span className="version" aria-label="application version">{version}</span>
          </div>
          <nav className="footer-links" aria-label="Footer navigation">
            <a href="#" aria-label="Privacy Policy link">Privacy</a>
            <a href="#" aria-label="Terms of Service link">Terms</a>
            <a href="mailto:support@attspace.example" aria-label="Support contact link">Support</a>
          </nav>
        </div>
        <div className="footer-divider" />
        <div className="footer-meta footer-meta--row" aria-label="copyright and team attribution">
          <span className="footer-copy">&copy; {year} ATTSpace. All rights reserved.</span>
          <span className="footer-team">Crafted with dedication by <strong>Team 404 Squad</strong>.</span>
        </div>
      </div>
    </footer>
  );
};

export default AppFooter;
