
import React, { useState, useEffect, useCallback } from 'react';
import girlPng from '../assets/girl.png';
import malePng from '../assets/male.png';
import notificationPng from '../assets/notification.png';

const NAV_ITEMS = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'benefits', label: 'Benefits' },
  { id: 'how-it-works', label: 'How It Works' },
  { id: 'services', label: 'Services' },
  { id: 'contact', label: 'Contact' },
];

const Header = ({ handleGetStarted, handleShowHome }) => {
  const [activeNav, setActiveNav] = useState('home');
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);

  // Update active nav on scroll
  const handleScroll = useCallback(() => {
    const sectionIds = ['home', 'about', 'benefits', 'how-it-works', 'services', 'contact'];
    let found = 'home';
    for (let i = 0; i < sectionIds.length; i++) {
      const section = document.getElementById(sectionIds[i]);
      if (section) {
        const rect = section.getBoundingClientRect();
        if (rect.top <= 80) {
          found = sectionIds[i];
        }
      }
    }
    setActiveNav(found);
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  // Set active nav on click
  const handleNavClick = (id) => {
    setActiveNav(id);
    // For smooth scroll
    setTimeout(() => {
      const section = document.getElementById(id);
      if (section) {
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 0);
    // If home, reset form to image
    if (id === 'home' && handleShowHome) {
      handleShowHome();
    }
  };



  return (
    <header className="fbs__net-navbar navbar navbar-expand-lg dark" aria-label="freebootstrap.net navbar">
      <div className="container-fluid p-0 d-flex justify-content-center align-items-center">
        <div className="container d-flex align-items-center justify-content-between" style={{minHeight: '72px', paddingLeft: 0, paddingRight: 0}}>
        {/* Start Logo */}
  <a className="navbar-brand w-auto d-flex align-items-center" href="#home" onClick={e => { e.preventDefault(); handleNavClick('home'); }}>
          <img className="logo attspace img-fluid" src="/src/assets/attspace.png" alt="ATT Space" style={{height: '34px', width: '34px', borderRadius: '50%', objectFit: 'cover', objectPosition: 'center'}} />
        </a>
        {/* Start offcanvas */}
        <div className="offcanvas offcanvas-start w-75" id="fbs__net-navbars" tabIndex="-1" aria-labelledby="fbs__net-navbarsLabel">
          <div className="offcanvas-header">
            <div className="offcanvas-header-logo">
              <a className="logo-link" id="fbs__net-navbarsLabel" href="#home" onClick={e => { e.preventDefault(); handleNavClick('home'); }}>
                <img className="logo attspace img-fluid" src="/src/assets/attspace.png" alt="ATT Space" style={{height: '34px', width: '34px', borderRadius: '50%', objectFit: 'cover', objectPosition: 'center'}} />
              </a>
            </div>
            <button className="btn-close btn-close-black" type="button" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div className="offcanvas-body align-items-lg-center">
            <ul className="navbar-nav nav me-auto ps-lg-5 mb-2 mb-lg-0">
              <li className="nav-item">
                <a className={`nav-link scroll-link${activeNav === 'home' ? ' active' : ''}`} aria-current="page" href="#home" onClick={e => { e.preventDefault(); handleNavClick('home'); }}>Home</a>
              </li>
              <li className="nav-item">
                <a className={`nav-link scroll-link${activeNav === 'about' ? ' active' : ''}`} href="#about" onClick={e => { e.preventDefault(); handleNavClick('about'); }}>About</a>
              </li>
              <li className="nav-item">
                <a className={`nav-link scroll-link${activeNav === 'benefits' ? ' active' : ''}`} href="#benefits" onClick={e => { e.preventDefault(); handleNavClick('benefits'); }}>Benefits</a>
              </li>
              <li className="nav-item">
                <a className={`nav-link scroll-link${activeNav === 'how-it-works' ? ' active' : ''}`} href="#how-it-works" onClick={e => { e.preventDefault(); handleNavClick('how-it-works'); }}>How It Works</a>
              </li>
              <li className="nav-item">
                <a className={`nav-link scroll-link${activeNav === 'services' ? ' active' : ''}`} href="#services" onClick={e => { e.preventDefault(); handleNavClick('services'); }}>Services</a>
              </li>
              <li className="nav-item">
                <a className={`nav-link scroll-link${activeNav === 'contact' ? ' active' : ''}`} href="#contact" onClick={e => { e.preventDefault(); handleNavClick('contact'); }}>Contact</a>
              </li>
            </ul>
          </div>
        </div>
        {/* End offcanvas */}
        <div className="w-auto d-flex align-items-center">
          <div className="header-social d-flex align-items-center gap-2">

            <a className="btn btn-primary py-1 px-3 navbar-btn-align" style={{fontSize:'0.95rem', minWidth:'90px', marginRight:'9rem'}} href="#getstarted" onClick={handleGetStarted}>Get Started</a>
            <div style={{display:'flex',alignItems:'center',gap:'0.7rem', marginLeft:'7rem'}}>
              {/* Notification dropdown first */}
              <div className="dropdown" style={{position: 'relative'}}>
                <img
                  src={notificationPng}
                  alt="Notifications"
                  style={{height: 48, width: 48, cursor: 'pointer'}}
                  onClick={() => {
                    setShowNotificationDropdown(v => !v);
                    setShowProfileDropdown(false);
                  }}
                />
                {showNotificationDropdown && (
                  <div
                    style={{
                      position: 'absolute',
                      right: 0,
                      top: '120%',
                      minWidth: '260px',
                      background: '#fff',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
                      borderRadius: '10px',
                      zIndex: 1000,
                      padding: '0.5rem 0',
                      border: '1px solid #eee',
                    }}
                    onMouseLeave={() => setShowNotificationDropdown(false)}
                  >
                    <div style={{padding:'0.7rem 1.2rem',fontSize:'0.97rem',color:'#222',borderBottom:'1px solid #eee'}}>Notifications</div>
                    <div style={{padding:'0.5rem 1.2rem',fontSize:'0.97rem',color:'#444'}}>🍎 Fruits collection in pantry is now available!</div>
                    <div style={{padding:'0.5rem 1.2rem',fontSize:'0.97rem',color:'#444'}}>🏢 The Ganga meeting room is booked at 7:00pm.</div>
                    <div style={{padding:'0.5rem 1.2rem',fontSize:'0.97rem',color:'#444'}}>🧘 Take a break for your health!</div>
                  </div>
                )}
              </div>
              {/* Profile dropdown second */}
              {(() => {
                const gender = Math.random() > 0.5 ? 'male' : 'female';
                const profileImg = gender === 'male' ? malePng : girlPng;
                return (
                  <div className="dropdown" style={{position: 'relative'}}>
                    <img
                      src={profileImg}
                      alt="Profile"
                      style={{height: 56, width: 56, cursor: 'pointer', borderRadius: '50%', background: '#f3f3f3', border: '1.5px solid #ddd'}}
                      onClick={() => {
                        setShowProfileDropdown(v => !v);
                        setShowNotificationDropdown(false);
                      }}
                    />
                    {showProfileDropdown && (
                      <div
                        style={{
                          position: 'absolute',
                          right: 0,
                          top: '120%',
                          minWidth: '160px',
                          background: '#fff',
                          boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
                          borderRadius: '10px',
                          zIndex: 1000,
                          padding: '0.5rem 0',
                          border: '1px solid #eee',
                        }}
                        onMouseLeave={() => setShowProfileDropdown(false)}
                      >
                        <a href="#profile" className="dropdown-item" style={{display:'flex',alignItems:'center',padding:'0.5rem 1rem',color:'#222',textDecoration:'none',fontSize:'0.97rem',gap:'0.7rem'}}>
                          <img src={profileImg} alt="Profile" style={{height:20,width:20,borderRadius:'50%'}} />
                          Profile
                        </a>
                        <div style={{borderTop:'1px solid #eee',margin:'0.3rem 0'}}></div>
                        <a href="#logout" className="dropdown-item" style={{display:'flex',alignItems:'center',padding:'0.5rem 1rem',color:'#d32f2f',textDecoration:'none',fontSize:'0.97rem',gap:'0.7rem'}}>
                          Logout
                        </a>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            <button className="fbs__net-navbar-toggler justify-content-center align-items-center" data-bs-toggle="offcanvas" data-bs-target="#fbs__net-navbars" aria-controls="fbs__net-navbars" aria-label="Toggle navigation" aria-expanded="false">
              <svg className="fbs__net-icon-menu" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="21" x2="3" y1="6" y2="6"></line>
                <line x1="15" x2="3" y1="12" y2="12"></line>
                <line x1="17" x2="3" y1="18" y2="18"></line>
              </svg>
              <svg className="fbs__net-icon-close" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
              </svg>
            </button>
          </div>
        </div>
          </div>
        </div>
      </header>
  );
};

export default Header;
