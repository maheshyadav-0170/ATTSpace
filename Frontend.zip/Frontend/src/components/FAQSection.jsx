import React from 'react';

const FAQSection = () => (
  <section className="section faq__v2" id="faq">
    <div className="container">
      <div className="row mb-4">
        <div className="col-md-6 col-lg-7 mx-auto text-center"><span className="subtitle text-uppercase mb-3" data-aos="fade-up" data-aos-delay="0">FAQ</span>
          <h2 className="h2 fw-bold mb-3" data-aos="fade-up" data-aos-delay="0">Frequently Asked Questions</h2>
          <p data-aos="fade-up" data-aos-delay="100">Learn how ATTSpace streamlines your workspace experience, enhances collaboration, and promotes well-being at AT&T.</p>
        </div>
      </div>
      <div className="row">
        <div className="col-md-8 mx-auto" data-aos="fade-up" data-aos-delay="200">
          <div className="faq-content">
            <div className="accordion custom-accordion" id="accordionPanelsStayOpenExample">
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">How do I access ATTSpace?</button>
                </h2>
                <div className="accordion-collapse collapse show" id="panelsStayOpen-collapseOne">
                  <div className="accordion-body">ATTSpace is accessible through the AT&T intranet as a web app or via the desktop application. Log in using your standard AT&T employee credentials to start booking workspaces, joining team challenges, or receiving wellness reminders.</div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">Is ATTSpace compatible with different desktop operating systems?</button>
                </h2>
                <div className="accordion-collapse collapse" id="panelsStayOpen-collapseTwo">
                  <div className="accordion-body">Yes, ATTSpace is fully compatible with major desktop operating systems, including Windows and macOS. The web app runs on all modern browsers, and the desktop app is optimized for seamless performance across these platforms.</div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">Can I use ATTSpace for both in-office and remote work?</button>
                </h2>
                <div className="accordion-collapse collapse" id="panelsStayOpen-collapseThree">
                  <div className="accordion-body">ATTSpace is designed to support AT&T’s hybrid work model. You can use it to reserve workspaces when planning in-office days or to participate in team challenges and wellness initiatives, keeping you connected whether you’re in the office or working remotely.</div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseFour" aria-expanded="false" aria-controls="panelsStayOpen-collapseFour">How does ATTSpace protect my data?</button>
                </h2>
                <div className="accordion-collapse collapse" id="panelsStayOpen-collapseFour">
                  <div className="accordion-body">ATTSpace integrates with AT&T’s secure infrastructure, employing robust encryption and authentication protocols to protect your booking and engagement data, ensuring a safe and reliable user experience.</div>
                </div>
              </div>
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseFive" aria-expanded="false" aria-controls="panelsStayOpen-collapseFive">What support is available if I encounter issues with ATTSpace?</button>
                </h2>
                <div className="accordion-collapse collapse" id="panelsStayOpen-collapseFive">
                  <div className="accordion-body">AT&T provides dedicated support for ATTSpace users through the internal IT helpdesk. You can access assistance via email, chat, or phone, and our team is available to resolve any technical issues or answer questions about the platform.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default FAQSection;
