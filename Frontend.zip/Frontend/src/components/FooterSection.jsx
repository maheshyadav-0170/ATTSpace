import React from 'react';

const FooterSection = () => (
  <footer className="footer pt-5 pb-5">
    <div className="container">
      <div className="row mb-5 pb-4">
        <div className="col-md-12">
          <h2 className="fs-5">About ATTSpace</h2>
          <p>ATTSpace streamlines workspace management, enhances collaboration, and promotes well-being for AT&T India employees, creating an efficient and connected hybrid work environment.</p>
        </div>
      </div>
      <div className="row justify-content-between mb-5 g-xl-5">
        <div className="col-md-4 col-lg-4 mb-5 mb-lg-0">
          <h3 className="mb-3">About</h3>
          <p className="mb-4">Designed to support AT&T’s hybrid workforce, ATTSpace empowers employees to seamlessly book workspaces, engage in team challenges, and optimize their workday.</p>
        </div>
        <div className="col-md-8 col-lg-8">
          <div className="row g-2">
            <div className="col-md-6 col-lg-6 mb-4 mb-lg-0">
              <h3 className="mb-3">Support</h3>
              <ul className="list-unstyled">
                <li><a href="#faq">FAQ</a></li>
                <li><a href="#contact">Contact Team404Squad</a></li>
                <li><a href="page-privacy-policy.html">Privacy Policy</a></li>
                <li><a href="page-terms-conditions.html">Terms & Conditions</a></li>
              </ul>
            </div>
            <div className="col-md-6 col-lg-6 mb-4 mb-lg-0 quick-contact">
              <h3 className="mb-3">Contact</h3>
              <p className="d-flex mb-3"><i className="bi bi-geo-alt-fill me-3"></i><span>10th, Innovator Building, ITPL Main Rd, Pattandur Agrahara, Whitefield, Bengaluru, Karnataka 560066, India</span></p>
              <a className="d-flex mb-3" href="mailto:support@attspace.att.com"><i className="bi bi-envelope-fill me-3"></i><span>support@attspace.att.com</span></a>
              <a className="d-flex mb-3" href="#"><i className="bi bi-ticket-fill me-3"></i><span>Submit via AT&T Intranet Portal</span></a>
            </div>
          </div>
        </div>
      </div>
      <div className="row credits pt-3">
        <div className="col-xl-8 text-center text-xl-start mb-3 mb-xl-0">
          &copy; {new Date().getFullYear()} ATTSpace. All rights reserved.
        </div>
        <div className="col-xl-4 justify-content-start justify-content-xl-end quick-links d-flex flex-column flex-xl-row text-center text-xl-start gap-1">
          Developed by Team 404 Squad
        </div>
      </div>
    </div>
  </footer>
);

export default FooterSection;
