import React, { useState, useEffect, useRef } from 'react';
import './IssueReporter.css';
// Hardcoded Issue Reporter API base URL (per request: no env / runtime overrides)
const ISSUE_API_BASE = 'http://localhost:4005';

// Categories specific to issues in the workspace (can expand later)
const ISSUE_TYPES = [
  'Workspace Issue',
  'Facility',
  'Hardware',
  'Network',
  'Access / Permission',
  'Other'
];

const ICON_MAP = {
  'Workspace Issue': 'fa-person-booth',
  'Facility': 'fa-building',
  'Hardware': 'fa-microchip',
  'Network': 'fa-wifi',
  'Access / Permission': 'fa-key',
  'Other': 'fa-flag'
};

const SEVERITIES = ['Minor','Moderate','Major','Critical'];
const IMPACTS = ['Single User','Team','Department / Floor','Entire Site'];
const LOCATIONS = [
  'Innovator - 10th Floor',
  'Innovator - 11th Floor',
  'Innovator - 12th Floor',
  'Innovation Hub - Ground',
  'Other'
];

const IssueReporter = () => {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState('Workspace Issue');
  const [summary, setSummary] = useState('');
  const [details, setDetails] = useState('');
  const [location, setLocation] = useState('Innovator - 10th Floor');
  const [otherLocation, setOtherLocation] = useState('');
  const [severity, setSeverity] = useState('Moderate');
  const [impact, setImpact] = useState('Single User');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false); // retained for any future logic
  const [phase, setPhase] = useState('form'); // 'form' | 'success'
  const [error, setError] = useState(null);
  const [createdIssue, setCreatedIssue] = useState(null); // store returned issue
  const dialogRef = useRef(null);
  const summaryRef = useRef(null);

  useEffect(() => {
    if (open && dialogRef.current) {
      setTimeout(() => summaryRef.current?.focus(), 30);
      const onKey = (e) => { if (e.key === 'Escape') handleClose(); };
      document.addEventListener('keydown', onKey);
      return () => document.removeEventListener('keydown', onKey);
    }
  }, [open]);

  useEffect(() => {
    // global opener for future triggers (e.g., from card "Feedback & Reports")
    window.openIssueReporter = () => setOpen(true);
    return () => { delete window.openIssueReporter; };
  }, []);

  const resetState = () => {
    setType('Workspace Issue');
    setSummary('');
    setDetails('');
  setLocation('Innovator - 10th Floor');
  setOtherLocation('');
    setSeverity('Moderate');
    setImpact('Single User');
  setSubmitted(false);
  setPhase('form');
    setError(null);
    setCreatedIssue(null);
  };

  const handleClose = () => {
    if (submitting) return;
    setOpen(false);
    setTimeout(() => resetState(), 250);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    if (!summary.trim()) { setError('Summary is required.'); return; }
  if (!location) { setError('Location / Floor is required.'); return; }
  if (location === 'Other' && !otherLocation.trim()) { setError('Please specify the location.'); return; }
    if (!severity) { setError('Severity is required.'); return; }
    if (!impact) { setError('Impact is required.'); return; }
    setSubmitting(true);
    try {
      const token = localStorage.getItem('token') || localStorage.getItem('authToken');
      if (!token) {
        throw new Error('Missing auth token. Please login again.');
      }

      const payload = {
        type,
        summary: summary.trim(),
        details: details.trim() || undefined,
        location,
        otherLocation: location === 'Other' ? otherLocation.trim() : undefined,
        severity,
        impact
      };

      const res = await fetch(`${ISSUE_API_BASE}/issue-reported/create-issue`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      let data;
      try { data = await res.json(); } catch { throw new Error(`Unexpected response (${res.status})`); }
      if (!res.ok || !data.success) {
        throw new Error(data.message || 'Failed to submit issue');
      }
      setCreatedIssue(data.issue);
      setSubmitted(true);
      setPhase('success');
      // Allow user to view success state longer (5s) before auto-close
      setTimeout(() => handleClose(), 5000);
    } catch (err) {
      setError(err.message || 'Failed to submit issue. Retry.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <button
        type="button"
        className="issue-fab"
        aria-label="Report an issue"
        title="Report an issue"
        onClick={() => setOpen(true)}
      >
        <span className="issue-fab-icon" aria-hidden="true"><i className="fas fa-flag" /></span>
        <span className="issue-fab-label">
          <span className="issue-fab-label-main">Report Issue</span>
          <span className="issue-fab-label-sub">Workspace</span>
        </span>
      </button>

      {open && (
        <div className="issue-overlay" role="presentation" onClick={handleClose}>
          <div
            className="issue-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="issue-title"
            aria-describedby="issue-desc"
            onClick={(e) => e.stopPropagation()}
            ref={dialogRef}
          >
            {phase === 'form' && (
              <>
                <div className="issue-header">
                  <div className="issue-header-left">
                    <span className="issue-type-icon" aria-hidden="true">
                      <i key={type} className={`fas ${ICON_MAP[type] || 'fa-flag'}`}></i>
                    </span>
                    <h3 id="issue-title" className="issue-title">Report an Issue</h3>
                  </div>
                  <button type="button" className="issue-close" onClick={handleClose} aria-label="Close issue dialog" disabled={submitting}>
                    <i className="fas fa-times" />
                  </button>
                </div>
                <p id="issue-desc" className="issue-intro">Describe the issue clearly. Your report will be automatically escalated to the Global Real Estate Team for triage. Please avoid including confidential or personal data.</p>
                <form onSubmit={handleSubmit} className="issue-form" noValidate>
                  <div className="form-row">
                    <label htmlFor="issue-type">Type</label>
                    <select id="issue-type" value={type} onChange={(e) => setType(e.target.value)} disabled={submitting || submitted}>
                      {ISSUE_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div className="issue-required-grid">
                    <div className="form-row">
                      <label htmlFor="issue-summary">Summary <span className="required">*</span></label>
                      <input
                        id="issue-summary"
                        ref={summaryRef}
                        type="text"
                        placeholder="e.g., Wi-Fi outage 3rd floor"
                        value={summary}
                        onChange={(e) => setSummary(e.target.value)}
                        maxLength={160}
                        disabled={submitting || submitted}
                      />
                      <div className="char-counter">{summary.length}/160</div>
                    </div>
                    <div className="form-row">
                      <label htmlFor="issue-location">Location / Floor <span className="required">*</span></label>
                      <select
                        id="issue-location"
                        value={location}
                        onChange={(e) => { setLocation(e.target.value); if (e.target.value !== 'Other') setOtherLocation(''); }}
                        disabled={submitting || submitted}
                        className="compact-select"
                      >
                        {LOCATIONS.map(l => <option key={l} value={l}>{l}</option>)}
                      </select>
                      {location === 'Other' && (
                        <input
                          type="text"
                          className="other-location-input"
                          placeholder="Specify location (e.g., Tower B - 3rd Floor)"
                          value={otherLocation}
                          onChange={(e) => setOtherLocation(e.target.value)}
                          maxLength={120}
                          disabled={submitting || submitted}
                          style={{marginTop:'6px'}}
                        />
                      )}
                    </div>
                    <div className="form-row">
                      <label htmlFor="issue-severity">Severity <span className="required">*</span></label>
                      <select id="issue-severity" value={severity} onChange={(e) => setSeverity(e.target.value)} disabled={submitting || submitted}>
                        {SEVERITIES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div className="form-row">
                      <label htmlFor="issue-impact">Impact <span className="required">*</span></label>
                      <select id="issue-impact" value={impact} onChange={(e) => setImpact(e.target.value)} disabled={submitting || submitted}>
                        {IMPACTS.map(i => <option key={i} value={i}>{i}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="form-row">
                    <label htmlFor="issue-details">Details</label>
                    <textarea
                      id="issue-details"
                      rows={3}
                      placeholder="Add details, steps, location, impact..."
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                      maxLength={2000}
                      disabled={submitting || submitted}
                    />
                    <div className="char-counter">{details.length}/2000</div>
                  </div>
                  <div className="form-row" style={{marginTop:'-4px'}}>
                    <small style={{fontSize:'.58rem', lineHeight:'1.2', color:'#64748b'}}>By submitting you confirm the information is accurate and appropriate for escalation.</small>
                  </div>
                  {error && <div className="issue-error" role="alert">{error}</div>}
                  <div className="issue-actions">
                    <button type="button" className="btn-secondary" onClick={handleClose} disabled={submitting}>Cancel</button>
                    <button type="submit" className="btn-primary" disabled={submitting || submitted}>{submitting ? 'Sending…' : 'Submit'}</button>
                  </div>
                </form>
              </>
            )}
            {phase === 'success' && (
              <div className="issue-success-state" aria-live="polite">
                <div className="issue-success-visual">
                  <img className="issue-success-gif" src="/assets/images/issue-done.gif" alt="Success" onError={(e)=>{e.currentTarget.style.display='none';}} />
                  <div className="issue-success-icon" aria-hidden="true"><i className="fas fa-check-circle" /></div>
                </div>
                <h4 className="issue-success-heading">Issue Submitted</h4>
                <p className="issue-success-message">Your report has been logged and routed to the Global Real Estate Team.</p>
                {createdIssue && (
                  <div className="issue-success-meta">
                    {createdIssue.meta && (
                      <small><strong>Role:</strong> {createdIssue.meta.isAdmin ? 'Administrator' : 'Reporter'}</small>
                    )}
                  </div>
                )}
                <div className="issue-success-progress"><span className="issue-progress-bar" /></div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default IssueReporter;
