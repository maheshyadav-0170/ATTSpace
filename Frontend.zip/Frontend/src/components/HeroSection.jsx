import React, { useState, useEffect } from 'react';
import axios from 'axios';


import './HeroSection.css';




const HeroSection = ({ showForm, handleGetStarted }) => {
  const [formState, setFormState] = useState('attuid');
  const [attuid, setAttuid] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [alert, setAlert] = useState({ message: '', type: '' });
  const [loading, setLoading] = useState(false);

  const API_URL = 'http://localhost:4000/auth';

  const showAlert = (message, type) => {
    setAlert({ message, type });
  };

  const clearAlert = () => {
    setAlert({ message: '', type: '' });
  };

  const handleAttuidSubmit = async (e) => {
    e.preventDefault();
    if (!attuid.trim()) {
      showAlert('Please enter a valid ATTUID.', 'danger');
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/check-attuid`, { attuid });
      showAlert(response.data.message, 'info');
      if (response.data.next === 'otp') {
        setFormState('otp');
      } else if (response.data.next === 'password') {
        setFormState('password');
      }
    } catch (err) {
      showAlert(err.response?.data?.message || 'Failed to connect to the server. Please try again later.', 'danger');
    }
    setLoading(false);
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    const otpValue = otp.join('');
    if (otpValue.length !== 6 || !/^[0-9]{6}$/.test(otpValue)) {
      showAlert('Please enter a valid 6-digit OTP.', 'danger');
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/verify-otp`, { attuid, otp: otpValue });
      showAlert(response.data.message, 'success');
      if (response.data.next === 'set-password') {
        setFormState('set-password');
      }
    } catch (err) {
      showAlert(err.response?.data?.message || 'Failed to verify OTP. Please try again later.', 'danger');
    }
    setLoading(false);
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    if (!password) {
      showAlert('Please enter a valid password.', 'danger');
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/login`, { attuid, password });
      showAlert('Login successful!', 'success');
      localStorage.setItem('authToken', response.data.token);
      // You can redirect or update UI here
    } catch (err) {
      showAlert(err.response?.data?.message || 'Failed to login. Please try again later.', 'danger');
    }
    setLoading(false);
  };

  const handleSetPasswordSubmit = async (e) => {
    e.preventDefault();
    if (!password || password !== confirmPassword) {
      showAlert('Passwords do not match or are invalid.', 'danger');
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/set-password`, { attuid, password });
      showAlert(response.data.message, 'success');
      setTimeout(() => {
        setFormState('attuid');
        setAttuid('');
        setPassword('');
        setConfirmPassword('');
        showAlert('Please sign in with your new password.', 'info');
      }, 2000);
    } catch (err) {
      showAlert(err.response?.data?.message || 'Failed to set password. Please try again later.', 'danger');
    }
    setLoading(false);
  };

  const handleOtpChange = (index, value) => {
    if (/^[0-9]?$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);
      if (value && index < 5) {
        document.getElementById(`otp-${index + 1}`).focus();
      }
    }
  };

  let formContent = null;
  // For fade transition, use a state to trigger fade class
  const [fadeClass, setFadeClass] = useState('');
  useEffect(() => {
    setFadeClass('fade-in');
    return () => setFadeClass('');
  }, [showForm, formState]);

  if (showForm) {
    formContent = (
      <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%'}}>
        <div className="login-card">
          <h3 className="mb-3 text-center" style={{ fontSize: '1.6rem', fontFamily: 'Aptos, Arial, sans-serif', fontWeight: 'normal' }}>
            {formState === 'attuid' && 'Sign In'}
            {formState === 'otp' && 'Enter OTP'}
            {formState === 'password' && 'Enter Password'}
            {formState === 'set-password' && 'Set Password'}
          </h3>
          {alert.message && (
            <div className={`alert alert-${alert.type} ${alert.message ? '' : 'd-none'}`}>{alert.message}</div>
          )}
          <div>
            {formState === 'attuid' && (
              <form onSubmit={handleAttuidSubmit}>
                <div className="mb-4">
                  <label htmlFor="attuid" className="form-label">ATTUID</label>
                  <input
                    type="text"
                    id="attuid"
                    className="form-control"
                    placeholder="Enter your ATTUID"
                    value={attuid}
                    onChange={e => setAttuid(e.target.value)}
                    required
                  />
                </div>
                <div className="d-grid">
                  <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Checking...' : 'Next'}</button>
                </div>
              </form>
            )}
            {formState === 'otp' && (
              <form onSubmit={handleOtpSubmit}>
                <div className="mb-4">
                  <label className="form-label">One-Time Password (OTP)</label>
                  <div className="otp-input" style={{display: 'flex', gap: '8px', justifyContent: 'center'}}>
                    {otp.map((digit, index) => (
                      <input
                        key={index}
                        id={`otp-${index}`}
                        type="text"
                        maxLength="1"
                        className="form-control"
                        style={{width: '2.5rem', textAlign: 'center', fontSize: '1.5rem'}}
                        value={digit}
                        onChange={e => handleOtpChange(index, e.target.value)}
                        required
                      />
                    ))}
                  </div>
                </div>
                <div className="d-grid">
                  <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Verifying...' : 'Verify'}</button>
                </div>
              </form>
            )}
            {formState === 'password' && (
              <form onSubmit={handlePasswordSubmit}>
                <div className="mb-4">
                  <label htmlFor="password" className="form-label">Password</label>
                  <input
                    type="password"
                    id="password"
                    className="form-control"
                    placeholder="Enter your password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="d-grid">
                  <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Logging in...' : 'Login'}</button>
                </div>
              </form>
            )}
            {formState === 'set-password' && (
              <form onSubmit={handleSetPasswordSubmit}>
                <div className="mb-4">
                  <label htmlFor="password" className="form-label">New Password</label>
                  <input
                    type="password"
                    id="password"
                    className="form-control"
                    placeholder="Enter your new password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="mb-4">
                  <label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
                  <input
                    type="password"
                    id="confirmPassword"
                    className="form-control"
                    placeholder="Confirm your password"
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>
                <div className="d-grid">
                  <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Setting...' : 'Set Password'}</button>
                </div>
              </form>
            )}
          </div>
            <div className="text-center text-sm text-gray-500 mt-6 mb-6" style={{marginTop: '1.5rem'}}>
              <div className="footer-text">
                <p style={{marginBottom: '0.5rem'}}>
                  <a href="#">Help</a> · <a href="#">Privacy</a> · <a href="#">Terms</a>
                </p>
                <p style={{marginTop: '0.5rem'}}>© 2025 AT&T – Confidential</p>
              </div>
            </div>
        </div>
      </div>
    );
  }


  return (
    <section className="hero__v6 section" id="home">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 mb-4 mb-lg-0">
            <div className="row">
              <div className="col-lg-11">
                <span className="hero-subtitle text-uppercase" data-aos="fade-up" data-aos-delay="0">Smart Space Reservation</span>
                <h1 className="hero-title mb-3" data-aos="fade-up" data-aos-delay="100">Book Spaces Seamlessly, Anytime, Anywhere</h1>
                <p className="hero-description mb-4 mb-lg-5" data-aos="fade-up" data-aos-delay="200">
                  Discover, reserve, and manage your spaces with ease. From meeting rooms to co-working areas — all in one platform.
                </p>
                <div className="cta d-flex gap-2 mb-4 mb-lg-5" data-aos="fade-up" data-aos-delay="300">
                  <button className="btn" style={{backgroundColor: '#5EABD6', borderColor: '#5EABD6', color: '#fff'}} onClick={handleGetStarted}>Get Started Now</button>
                  <a
                    className="btn no-hover"
                    href="#"
                    ref={el => {
                      if (el) {
                        el.style.setProperty('background-color', '#fff', 'important');
                        el.style.setProperty('color', '#000', 'important');
                        el.style.setProperty('border', '1px solid #5EABD6', 'important');
                        el.style.setProperty('box-shadow', 'none', 'important');
                        el.style.setProperty('outline', 'none', 'important');
                      }
                    }}
                  >
                    Learn More
                    <svg className="lucide lucide-arrow-up-right" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M7 7h10v10"></path>
                      <path d="M7 17 17 7"></path>
                    </svg>
                  </a>
                </div>
                <div className="logos mb-4" data-aos="fade-up" data-aos-delay="400">
                  <span className="logos-title text-uppercase mb-4 d-block">Powered by AT&T TEAMS</span>
                  <div className="logos-images d-flex gap-4 align-items-center">
                    <img className="img-fluid js-img-to-inline-svg" src="https://cdn.freebiesupply.com/images/large/2x/att-logo-black-transparent.png" alt="AT&T TEAMS Logo" style={{width: '140px'}} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-6">
            <div className="hero-img" style={{ minHeight: '400px' }}>
              <div className={fadeClass} style={{height: '400px', width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                  {formContent || (
                    <img className="img-main img-fluid rounded-4 mt-5" style={{height: '400px', width: '100%', objectFit: 'cover', maxWidth: '500px', minWidth: '320px'}} src="/assets/images/hero-img-1-min.jpg" alt="Hero" data-aos="fade-in" data-aos-delay="500" />
                  )}
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
