import React from 'react';

const BenefitsSection = () => (
  <section className="section pricing__v2" id="benefits">
    <div className="container">
      <div className="row mb-5">
        <div className="col-md-5 mx-auto text-center">
          <span className="subtitle text-uppercase mb-3" data-aos="fade-up" data-aos-delay="0">Benefits</span>
          <h2 className="mb-3" data-aos="fade-up" data-aos-delay="100">Elevate Your Workplace Experience</h2>
          <p data-aos="fade-up" data-aos-delay="200">ATTSpace delivers a sophisticated, integrated platform to streamline workspace management, enhance collaboration, and promote holistic employee well-being.</p>
        </div>
      </div>
      <div className="row">
        <div className="col-md-4 mb-4 mb-md-0" data-aos="fade-up" data-aos-delay="300">
          <div className="p-5 rounded-4 price-table h-100">
            <h3>Employee Features</h3>
            <p>Effortlessly reserve desks, engage in team challenges, and stay healthy with intuitive tools tailored to your hybrid work needs.</p>
            <div className="mb-4"><strong>Seamless Access</strong><span> for all AT&T employees</span></div>
            <div><a className="btn" href="#book-desk">Start Booking</a></div>
          </div>
        </div>
        <div className="col-md-8" data-aos="fade-up" data-aos-delay="400">
          <div className="p-5 rounded-4 price-table popular h-100">
            <div className="row">
              <div className="col-md-6">
                <h3 className="mb-3">Admin Tools</h3>
                <p>Optimize workspace strategies with robust management tools and data-driven insights for a more efficient office environment.</p>
                <div className="mb-4"><strong>Powerful Control</strong><span> for workspace admins</span></div>
                <div><a className="btn btn-white hover-outline" href="#analytics">Explore Analytics</a></div>
              </div>
              <div className="col-md-6 pricing-features">
                <h4 className="text-uppercase fw-bold mb-3">Key Features</h4>
                <ul className="list-unstyled d-flex flex-column gap-3">
                  <li className="d-flex gap-2 align-items-start mb-0"><span className="icon rounded-circle position-relative mt-1"><i className="bi bi-check"></i></span><span>Smart desk and meeting room reservations</span></li>
                  <li className="d-flex gap-2 align-items-start mb-0"><span className="icon rounded-circle position-relative mt-1"><i className="bi bi-check"></i></span><span>AI-driven space allocation and focus zones</span></li>
                  <li className="d-flex gap-2 align-items-start mb-0"><span className="icon rounded-circle position-relative mt-1"><i className="bi bi-check"></i></span><span>Wellness notifications and fruit alerts</span></li>
                  <li className="d-flex gap-2 align-items-start mb-0"><span className="icon rounded-circle position-relative mt-1"><i className="bi bi-check"></i></span><span>Gamified team challenges for collaboration</span></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default BenefitsSection;
