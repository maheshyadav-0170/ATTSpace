import { useState } from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import './Navbar.css';

/* Public (not logged-in) navigation bar */
export default function PublicNavbar() {
  const [expanded, setExpanded] = useState(false);

  const close = () => setExpanded(false);

  const handleOpenFeedback = () => {
    if (window.openFeedbackReporter) {
      window.openFeedbackReporter();
      close();
    } else {
      const btn = document.querySelector('.feedback-fab');
      btn?.click();
    }
  };

  return (
    <Navbar expanded={expanded} onToggle={setExpanded} expand="lg" bg="white" className="navbar-shadow att-navbar px-3" role="navigation" aria-label="Public navigation">
      <Container fluid>
        <Navbar.Brand as={Link} to="/" className="att-brand">
          <span className="att-brand-icon"><i className="fas fa-home" /></span>
          Attspace
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="public-nav" />
        <Navbar.Collapse id="public-nav">
          <Nav className="me-auto att-nav-group">
            <Nav.Link as={Link} to="/#features" onClick={close}>Features</Nav.Link>
            <Nav.Link as={Link} to="/#spaces" onClick={close}>Spaces</Nav.Link>
            <Nav.Link as={Link} to="/#pricing" onClick={close}>Pricing</Nav.Link>
            <Nav.Link as={Link} to="/#contact" onClick={close}>Contact</Nav.Link>
            <Nav.Link onClick={handleOpenFeedback}>Feedback</Nav.Link>
          </Nav>
          <Nav className="att-nav-actions">
            <Nav.Link as={Link} to="/home" className="signin-link" onClick={close}>Sign In</Nav.Link>
            <button type="button" className="btn btn-primary get-started-btn" onClick={() => { window.location.href = '/home'; }}>Get Started</button>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
