import React from 'react';
import './AssistantFab.css';

// Floating Assistant FAB (non-functional placeholder)
// Props allow future customization without editing all pages
const AssistantFab = ({
  labelMain = 'Workspace Assistant',
  labelSub = '(coming soon)',
  ariaLabel = 'Open Workspace Assistant (coming soon)',
  title = 'Workspace Assistant (coming soon)',
  variant = 'friendly'
}) => {
  return (
    <button
      type="button"
      className={`bot-fab bot-fab--${variant}`}
      aria-label={ariaLabel}
      title={title}
    >
      <span className="bot-fab-icon" aria-hidden="true">
        <i className="fas fa-comments"></i>
        <span className="bot-fab-spark" aria-hidden="true"></span>
      </span>
      <span className="bot-fab-label">
        <span className="bot-fab-label-main">{labelMain}</span>
        {labelSub && (
          <span className="bot-fab-label-sub">{labelSub}</span>
        )}
      </span>
    </button>
  );
};

export default AssistantFab;
