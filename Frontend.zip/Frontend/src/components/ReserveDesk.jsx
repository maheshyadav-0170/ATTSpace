
import React, { useState } from 'react';
import { TbArmchair } from "react-icons/tb";

import Sidebar from './Sidebar';
import './ReserveDesk.css';


const ReserveDesk = () => {
  // Example desk data for 3 rows

  // Arrange chairs in a grid with vertical dividers (4 blocks of 5x3)
  // Each block: 5 rows, 3 columns
  // Example: some unavailable, rest available

  // Helper to render a row of chairs
  const ChairRow = ({ count, direction = 'right', unavailable = [], keyPrefix = '', onClick, selectedIdx, blockIdx, rowIdx, colStart = 0, vertical = false, showNumbers = false }) => (
    <div style={{ display: 'flex', flexDirection: vertical ? 'column' : 'row', alignItems: 'center', justifyContent: 'center', gap: '0.7rem' }}>
      {Array.from({ length: count }).map((_, i) => {
        const idx = colStart + i;
        const isUnavailable = unavailable.includes(i);
        const isSelected = selectedIdx && selectedIdx[0] === blockIdx && selectedIdx[1] === rowIdx && selectedIdx[2] === idx;
        let rotate = 0;
        if (direction === 'up') rotate = -180;
        else if (direction === 'left') rotate = -90;
        else if (direction === 'right') rotate = 90;
        // down = 0
        return (
          <div key={keyPrefix + i} style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            {showNumbers && vertical && <span style={{ minWidth: 16, fontSize: '1rem', color: '#888' }}>{i + 1}</span>}
            <button
              className={`desk-chair small ${isUnavailable ? 'unavailable' : 'available'}${isSelected ? ' selected' : ''}`}
              disabled={isUnavailable}
              onClick={() => onClick && !isUnavailable && onClick([blockIdx, rowIdx, idx])}
              tabIndex={isUnavailable ? -1 : 0}
              aria-label={(isUnavailable ? 'Unavailable' : 'Available') + ' chair'}
              style={{ padding: 0, background: 'transparent', border: 'none' }}
            >
              <TbArmchair style={{ transform: `rotate(${rotate}deg)` }} />
            </button>
          </div>
        );
      })}
    </div>
  );

  // Track selected chair: [blockIdx, rowIdx, colIdx]
  const [selected, setSelected] = useState(null);

  // Toggle selection: unselect if already selected
  const handleChairClick = (idxArr) => {
    if (selected && selected[0] === idxArr[0] && selected[1] === idxArr[1] && selected[2] === idxArr[2]) {
      setSelected(null);
    } else {
      setSelected(idxArr);
    }
  };

  return (
    <div className="reserve-desk-layout">
      <Sidebar />
      <div className="reserve-desk-3col-bg" style={{ overflowX: 'hidden', overflowY: 'auto', height: '100vh', width: '100%', background: 'none', marginLeft: '120px' }}>
        <div className="reserve-desk-3col-container" style={{ display: 'flex', flexDirection: 'column', gap: '2rem', background: 'none', boxShadow: 'none', padding: 0, marginTop: '2rem', width: '100%' }}>
          {/* Legend Section */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '2.5rem', margin: '0 0 1.5rem 0', fontSize: '1.08rem', width: '100%' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ display: 'inline-block', width: 20, height: 20, background: '#1ecb7b', borderRadius: 4, border: '1px solid #e0e0e0' }}></span>
              <span>Available</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ display: 'inline-block', width: 20, height: 20, background: '#3a8bff', borderRadius: 4, border: '1px solid #e0e0e0' }}></span>
              <span>Selected</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ display: 'inline-block', width: 20, height: 20, background: '#b2c2e0', borderRadius: 4, border: '1px solid #e0e0e0' }}></span>
              <span>Unavailable</span>
            </div>
          </div>
          {/* New Top Section: 3 rooms in a row, each with a vertical column of 6 chairs facing down */}
          <div style={{ display: 'flex', flexDirection: 'row', gap: '2rem', width: '100%' }}>
            {/* Room 1 */}
            <div className="room-section" style={{ flex: 1, minWidth: 180, maxWidth: 300, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <div className="room-label">Room 1</div>
                <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
                  <ChairRow count={6} direction="left" keyPrefix="room1-left-vert-" blockIdx={10} rowIdx={0} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} vertical={true} />
                  <div className="room-rect-vert" style={{ height: '260px', minWidth: '48px', margin: '0 1.2rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span style={{ writingMode: 'vertical-rl', textAlign: 'center' }}>Single Long Room</span></div>
                  <ChairRow count={6} direction="right" keyPrefix="room1-right-vert-" blockIdx={10} rowIdx={1} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} vertical={true} />
                </div>
                         </div>
            {/* Room 2 */}
            <div className="room-section" style={{ flex: 1, minWidth: 180, maxWidth: 300, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <div className="room-label">Room 2</div>
              <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
                  <ChairRow count={6} direction="left" keyPrefix="room2-left-vert-" blockIdx={11} rowIdx={0} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} vertical={true} />
                  <div className="room-rect-vert" style={{ height: '260px', minWidth: '48px', margin: '0 1.2rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span style={{ writingMode: 'vertical-rl', textAlign: 'center' }}>Single Long Room</span></div>
                  <ChairRow count={6} direction="right" keyPrefix="room2-right-vert-" blockIdx={11} rowIdx={1} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} vertical={true} />
                </div>
                             </div>
            {/* Room 3 */}
            <div className="room-section" style={{ flex: 1, minWidth: 180, maxWidth: 300, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
              <div className="room-label">Room 3</div>
              <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
                  <ChairRow count={6} direction="left" keyPrefix="room3-left-vert-" blockIdx={12} rowIdx={0} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} vertical={true} />
                  <div className="room-rect-vert" style={{ height: '260px', minWidth: '48px', margin: '0 1.2rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><span style={{ writingMode: 'vertical-rl', textAlign: 'center' }}>Single Long Room</span></div>
                  <ChairRow count={6} direction="right" keyPrefix="room3-right-vert-" blockIdx={12} rowIdx={1} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} vertical={true} />
                </div>
                             </div>
          </div>
          {/* Room 1 */}
          <div style={{ display: 'flex', flexDirection: 'row', gap: '1.5rem', width: '100%' }}>
            <div className="room-section" style={{ flex: '1 1 100%', minWidth: 600, maxWidth: 900 }}>
              <div className="room-label">Single Long Room</div>
              <div className="room-rect-layout">
                <ChairRow count={6} direction="down" keyPrefix="slr-top-" blockIdx={6} rowIdx={0} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} />
                <div className="room-rect"><span>Single Long Room</span></div>
                <ChairRow count={6} direction="up" keyPrefix="slr-bottom-" blockIdx={6} rowIdx={1} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} />
              </div>
            </div>
          </div>
          {/* Room 2 */}
          <div style={{ display: 'flex', flexDirection: 'row', gap: '1.5rem', width: '100%' }}>
            <div className="room-section" style={{ flex: '1 1 100%', minWidth: 600, maxWidth: 900 }}>
              <div className="room-rect-layout">
                <ChairRow count={6} direction="down" keyPrefix="alr-top-" blockIdx={7} rowIdx={0} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} />
                <div className="room-rect"></div>
                <ChairRow count={6} direction="up" keyPrefix="alr-bottom-" blockIdx={7} rowIdx={1} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} />
              </div>
            </div>
          </div>
          {/* Room 3 */}
          <div style={{ display: 'flex', flexDirection: 'row', gap: '1.5rem', width: '100%' }}>
            <div className="room-section" style={{ flex: '1 1 100%', minWidth: 600, maxWidth: 900 }}>
              <div className="room-label">Third Long Room</div>
              <div className="room-rect-layout">
                <ChairRow count={6} direction="down" keyPrefix="tlr-top-" blockIdx={8} rowIdx={0} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} />
                <div className="room-rect"><span>Third Long Room</span></div>
                <ChairRow count={6} direction="up" keyPrefix="tlr-bottom-" blockIdx={8} rowIdx={1} selectedIdx={selected} onClick={handleChairClick} unavailable={[18,19]} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReserveDesk;
