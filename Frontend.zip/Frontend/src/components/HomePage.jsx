
import React, { useState } from 'react';
import './HomeCards.css';
import deskImg from '../assets/desk.png';
import meetImg from '../assets/meet.png';
import playImg from '../assets/play.png';
import exploreImg from '../assets/explore.png';

const cardData = [
	{
		title: 'desk reservation',
		link: '/reserve-desk',
		linkText: 'Reserve Now',
		content: 'Book your personal workspace for the day or week. Enjoy a comfortable, productive environment tailored to your needs.',
		img: deskImg
	},
	{
		title: 'meeting room reservation',
		link: '/reserve-meeting',
		linkText: 'Reserve Now',
		content: 'Reserve a meeting room equipped with all the amenities for your next team discussion or client meeting.',
		img: meetImg
	},
	{
		title: 'play arena',
		link: '/play-arena',
		linkText: 'Join Now',
		content: 'Take a break and have fun! Access our play arena for games, relaxation, and team bonding.',
		img: playImg
	},
	   {
		   title: 'explore more',
		   link: '',
		   linkText: '',
		   content: '',
		   img: exploreImg,
		   list: [
			   { name: 'Cafeteria', url: '/cafeteria' },
			   { name: 'Events', url: '/events' },
			   { name: 'Workshops', url: '/workshops' },
			   { name: 'More...', url: '/more' }
		   ]
	   }
];

const HomePage = () => {
	const [hovered, setHovered] = useState(null);

	const getCardMoveClass = (idx) => {
		switch (hovered) {
			case 0:
				if (idx === 1 || idx === 2 || idx === 3) return 'move-right';
				break;
			case 1:
				if (idx === 0) return 'move-left';
				if (idx === 2 || idx === 3) return 'move-right';
				break;
			case 2:
				if (idx === 0 || idx === 1) return 'move-left';
				if (idx === 3) return 'move-right';
				break;
			case 3:
				if (idx === 0 || idx === 1 || idx === 2) return 'move-left';
				break;
			default:
				return '';
		}
		return '';
	};

	return (
		<div className="home-cards-container">
			{cardData.map((card, idx) => (
				<div
					key={card.title}
					className={`home-card${hovered === idx ? '' : hovered !== null ? ' shrink' : ''} ${hovered !== null ? getCardMoveClass(idx) : ''}`}
					onMouseEnter={() => setHovered(idx)}
					onMouseLeave={() => setHovered(null)}
				>
															 <div className={`home-card-section header${hovered === idx && card.img ? ' hovered' : ''}`}> 
																 {card.img && (
																	 <div className={`home-card-img-wrap${hovered === idx ? ' hovered' : ''}`}>
																		 <img src={card.img} alt={card.title} className="home-card-img" />
																	 </div>
																 )}
																 <div className={`home-card-title${card.img ? ' with-img' : ''}${hovered === idx && card.img ? ' beside-img' : ''}`}>{card.title}</div>
															 </div>
					<div className="home-card-section center">
						{card.content && (
							<div className="home-card-content">{card.content}</div>
						)}
						{card.title === 'explore more' && (
							<div className="home-card-content" style={{opacity: hovered === idx ? 1 : 0, pointerEvents: hovered === idx ? 'auto' : 'none'}}>
								<ul style={{margin: 0, padding: 0, listStyle: 'none'}}>
									{card.list.map((item, i) => (
										<li key={item.name} style={{marginBottom: i === card.list.length - 1 ? 0 : '0.5rem'}}>
											<a href={item.url} className="home-card-list-link">{item.name}</a>
										</li>
									))}
								</ul>
							</div>
						)}
					</div>
					<div className="home-card-section bottom">
						{card.link && card.content && (
							<a href={card.link} className="home-card-link">{card.linkText}</a>
						)}
					</div>
				</div>
			))}
		</div>
	);
};

export default HomePage;
