import React, { useState, useRef, useEffect } from 'react';
import './FeedbackReporter.css';

// Simple in-memory categories (can be replaced later by API)
const FEEDBACK_CATEGORIES = [
  'Bug',
  'Idea',
  'UI / UX',
  'Performance',
  'Content',
  'Other'
];

// Map category to an icon (Font Awesome classes)
const CATEGORY_ICON_MAP = {
  'Bug': 'fa-bug',
  'Idea': 'fa-lightbulb',
  'UI / UX': 'fa-object-group',
  'Performance': 'fa-gauge-high',
  'Content': 'fa-file-lines',
  'Other': 'fa-comment-dots'
};

const FeedbackReporter = () => {
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState('Bug');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false); // retained for any future logic reuse
  const [phase, setPhase] = useState('form'); // 'form' | 'success'
  const [error, setError] = useState(null);
  const [successKey, setSuccessKey] = useState(0); // forces progress bar animation restart
  const dialogRef = useRef(null);
  const messageRef = useRef(null);

  // Trap focus rudimentarily when modal opens
  useEffect(() => {
    if (open && dialogRef.current) {
      // Delay to ensure rendering
      setTimeout(() => {
        messageRef.current?.focus();
      }, 30);
      const handleKey = (e) => {
        if (e.key === 'Escape') {
          handleClose();
        }
      };
      document.addEventListener('keydown', handleKey);
      return () => document.removeEventListener('keydown', handleKey);
    }
  }, [open]);

  const handleOpen = () => {
    setOpen(true);
  };

  // Expose global open function so nav / other components can trigger the reporter
  useEffect(() => {
    window.openFeedbackReporter = () => setOpen(true);
    return () => { delete window.openFeedbackReporter; };
  }, []);

  const handleClose = () => {
    if (submitting) return;
    setOpen(false);
    setTimeout(() => {
      setSubmitted(false);
      setError(null);
      setMessage('');
      setCategory('Bug');
      setPhase('form');
    }, 300);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    if (!message.trim()) {
      setError('Please enter a brief description.');
      return;
    }
    // (Steps/severity removed in simplified version)
    setSubmitting(true);
    // Simulate async (no backend yet)
    try {
      await new Promise(r => setTimeout(r, 650));
      // Placeholder: would POST to server
      console.log('[FeedbackReporter] payload', {
        category,
        message,
        ts: new Date().toISOString()
      });
      setSubmitted(true);
      setPhase('success');
      setSuccessKey(Date.now());
      // Auto close after success display (5s) similar to IssueReporter
      setTimeout(() => handleClose(), 5000);
    } catch (err) {
      setError('Failed to send feedback. Please retry.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      {/* Floating Feedback FAB */}
      <button
        type="button"
        className="feedback-fab"
        onClick={handleOpen}
        aria-label="Open feedback form"
        title="Give Feedback"
      >
        <span className="feedback-fab-icon" aria-hidden="true"><i className="fas fa-lightbulb"></i></span>
        <span className="feedback-fab-badge" aria-hidden="true">New</span>
        <span className="feedback-fab-label">
          <span className="feedback-fab-label-main">Share Feedback</span>
          <span className="feedback-fab-label-sub">Ideas • Issues</span>
        </span>
      </button>

      {open && (
        <div className="feedback-overlay" role="presentation" onClick={handleClose}>
          <div
            className="feedback-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="feedback-title"
            aria-describedby="feedback-desc"
            onClick={(e) => e.stopPropagation()}
            ref={dialogRef}
          >
            {phase === 'form' ? (
              <>
                <div className="feedback-header">
                  <div className="feedback-header-left">
                    <span className="feedback-category-icon" aria-hidden="true">
                      <i key={category} className={`fas ${CATEGORY_ICON_MAP[category] || 'fa-comment-dots'}`}></i>
                    </span>
                    <h3 id="feedback-title" className="feedback-title">Share Feedback</h3>
                  </div>
                  <button
                    type="button"
                    className="feedback-close"
                    onClick={handleClose}
                    aria-label="Close feedback dialog"
                    disabled={submitting}
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
                <p id="feedback-desc" className="feedback-intro">Share a quick note about an issue, idea, or improvement opportunity to help enhance ATTSpace.</p>
                <form onSubmit={handleSubmit} className="feedback-form" noValidate>
                  <div className="form-row">
                    <label htmlFor="feedback-category">Category</label>
                    <select
                      id="feedback-category"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      disabled={submitting || submitted}
                      className="feedback-select"
                    >
                      {FEEDBACK_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div className="form-row">
                    <label htmlFor="feedback-message">Description <span className="required">*</span></label>
                    <textarea
                      id="feedback-message"
                      ref={messageRef}
                      rows={5}
                      placeholder="Describe the issue, idea, or improvement..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      maxLength={2000}
                      disabled={submitting || submitted}
                    />
                    <div className="char-counter">{message.length}/2000</div>
                  </div>
                  {error && <div className="feedback-error" role="alert">{error}</div>}
                  <div className="feedback-actions">
                    <button type="button" className="btn-secondary" onClick={handleClose} disabled={submitting}>Cancel</button>
                    <button type="submit" className="btn-primary" disabled={submitting || submitted}>
                      {submitting ? 'Sending…' : submitted ? 'Sent' : 'Submit'}
                    </button>
                  </div>
                </form>
              </>
            ) : (
              <div className="feedback-success-state" aria-live="polite">
                <div className="feedback-success-visual">
                  <img
                    className="feedback-success-gif"
                    src="/assets/images/issue-done.gif"
                    alt="Success"
                    onError={(e)=>{ e.currentTarget.style.display='none'; }}
                  />
                  <div className="feedback-success-icon" aria-hidden="true"><i className="fas fa-check-circle" /></div>
                </div>
                <h4 className="feedback-success-heading">Feedback Submitted</h4>
                <p className="feedback-success-message">Thank you — your feedback has been received and will help us continually enhance the workspace experience.</p>
                <div className="feedback-success-progress"><span key={successKey} className="feedback-progress-bar" /></div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default FeedbackReporter;
