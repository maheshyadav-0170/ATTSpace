import React from 'react';
import './FloorMapFab.css';

/**
 * FloorMapFab
 * Floating action button that opens the floor map / wayfinding panel.
 * Exposes a placeholder click until window.openFloorMap is implemented elsewhere.
 */
const FloorMapFab = () => {
  const handleClick = () => {
    if (window.openFloorMap) {
      window.openFloorMap();
    } else {
      console.log('[FloorMapFab] Placeholder: implement window.openFloorMap()');
    }
  };

  return (
    <button
      type="button"
      className="floor-map-fab"
      aria-label="Open floor map"
      title="Floor Map"
      onClick={handleClick}
    >
      <span className="floor-map-fab-icon" aria-hidden="true"><i className="fas fa-map-location-dot" /></span>
      <span className="floor-map-fab-label">
        <span className="floor-map-fab-label-main">Floor Map</span>
      </span>
    </button>
  );
};

export default FloorMapFab;
