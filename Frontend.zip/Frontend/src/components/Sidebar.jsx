import React from 'react';
import './ReserveDesk.css';

const Sidebar = () => (
  <aside className="reserve-desk-sidebar">
    <nav className="reserve-desk-nav">
      <a className="active" href="#">My Bookings</a>
      <a href="#">Settings</a>
    </nav>
  </aside>
);

export default Sidebar;
