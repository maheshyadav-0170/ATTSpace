import React from 'react';

const AboutSection = () => (
  <section className="about__v4 section" id="about">
    <div className="container">
      <div className="row">
        <div className="col-md-6 order-md-2">
          <div className="row justify-content-end">
            <div className="col-md-11 mb-4 mb-md-0">
              <span className="subtitle text-uppercase mb-3" data-aos="fade-up" data-aos-delay="0">About ATTSpace</span>
              <h2 className="mb-4" data-aos="fade-up" data-aos-delay="100">Streamline your AT&T workspace with smart, intuitive tools</h2>
              <div data-aos="fade-up" data-aos-delay="200">
                <p>ATTSpace is an in-house platform built to tackle workspace inefficiencies in AT&T's hybrid work environment. It simplifies desk and meeting room bookings, optimizes space usage, and enhances employee well-being.</p>
                <p>Powered by AI, ATTSpace provides employees with seamless tools to reserve spaces, engage in team challenges, and stay healthy with wellness reminders, while offering admins data-driven insights to create a more efficient and connected workplace.</p>
              </div>
              <h4 className="small fw-bold mt-4 mb-3" data-aos="fade-up" data-aos-delay="300">Our Core Values</h4>
              <ul className="d-flex flex-row flex-wrap list-unstyled gap-3 features" data-aos="fade-up" data-aos-delay="400">
                <li className="d-flex align-items-center gap-2"><span className="icon rounded-circle text-center"><i className="bi bi-check"></i></span><span className="text">Efficiency</span></li>
                <li className="d-flex align-items-center gap-2"><span className="icon rounded-circle text-center"><i className="bi bi-check"></i></span><span className="text">Engagement</span></li>
                <li className="d-flex align-items-center gap-2"><span className="icon rounded-circle text-center"><i className="bi bi-check"></i></span><span className="text">Wellness</span></li>
                <li className="d-flex align-items-center gap-2"><span className="icon rounded-circle text-center"><i className="bi bi-check"></i></span><span className="text">Data-Driven Insight</span></li>
                <li className="d-flex align-items-center gap-2"><span className="icon rounded-circle text-center"><i className="bi bi-check"></i></span><span className="text">Collaboration</span></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="col-md-6"> 
          <div className="img-wrap position-relative">
            <img className="img-fluid rounded-4" src="/assets/images/about_2-min.jpg" alt="About" data-aos="fade-up" data-aos-delay="0" />
            <div className="mission-statement p-4 rounded-4 d-flex gap-4" data-aos="fade-up" data-aos-delay="100">
              <div className="mission-icon text-center rounded-circle"><i className="bi bi-lightbulb fs-4"></i></div>
              <div>
                <h3 className="text-uppercase fw-bold">Our Mission</h3>
                <p className="fs-5 mb-0">To empower AT&T employees with a smart, integrated platform that simplifies workspace management, fosters collaboration, and promotes well-being.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default AboutSection;
