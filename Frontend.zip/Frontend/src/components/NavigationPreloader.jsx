import React from 'react';
import './NavigationPreloader.css';

/**
 * NavigationPreloader
 * A branded, accessible loading overlay shown during short navigations.
 * - Animated orbit with accent dots
 * - Pulsing core
 * - Indeterminate progress bar (grows + wipes for perceived speed)
 */
export default function NavigationPreloader({ label = 'Loading', appName = 'AttSpace', mediaSrc = '/assets/branding/loader.svg', mediaAlt = 'Loading' }) {
  return (
    <div className="nav-preloader" role="alert" aria-live="polite" aria-busy="true">
      <div className="np-brand" aria-label={appName + ' loading'}>
        {appName.split('').map((ch, i) => (
          <span key={i} style={{ animationDelay: `${i * 55}ms` }}>{ch === ' ' ? '\u00A0' : ch}</span>
        ))}
      </div>
      {mediaSrc ? (
        <div className="np-media-wrapper" aria-hidden="true">
          <img className="np-media" src={mediaSrc} alt={mediaAlt} draggable="false" />
        </div>
      ) : (
        <div className="np-visual" aria-hidden="true">
          <div className="np-orbit">
            <span className="np-dot d1" />
            <span className="np-dot d2" />
            <span className="np-dot d3" />
          </div>
          <div className="np-core">
            <span className="np-core-pulse" />
            <span className="np-core-ring" />
          </div>
        </div>
      )}
      <div className="np-progress" aria-hidden="true">
        <div className="np-bar" />
      </div>
      <p className="np-text">{label}</p>
    </div>
  );
}
