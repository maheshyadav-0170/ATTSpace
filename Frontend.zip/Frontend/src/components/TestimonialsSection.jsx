import React from 'react';

const TestimonialsSection = () => (
  <section className="section testimonials__v2" id="testimonials">
    <div className="container">
      <div className="row mb-5">
        <div className="col-lg-5 mx-auto text-center"><span className="subtitle text-uppercase mb-3" data-aos="fade-up" data-aos-delay="0">Feedbacks</span>
          <h2 className="mb-3" data-aos="fade-up" data-aos-delay="100">What AT&T Employees Are Saying</h2>
          <p data-aos="fade-up" data-aos-delay="200">Real stories of how ATTSpace enhances productivity, collaboration, and well-being in our workplace</p>
        </div>
      </div>
      <div className="row g-4" data-masonry="{&quot;percentPosition&quot;: true }">
        <div className="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
          <div className="testimonial rounded-4 p-4">
            <blockquote className="mb-3">&ldquo;ATTSpace has made booking my desk so easy! I can quickly find a spot that suits my schedule, which has streamlined my workday and boosted my productivity.&rdquo;</blockquote>
            <div className="testimonial-author d-flex gap-3 align-items-center">
              <div className="author-img"><img className="rounded-circle img-fluid" src="/assets/images/person-sq-2-min.jpg" alt="ATTSpace employee" /></div>
              <div className="lh-base"><strong className="d-block">Arjun Patel</strong><span>Software Engineer</span></div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
          <div className="testimonial rounded-4 p-4">
            <blockquote className="mb-3">&ldquo;The wellness reminders have been a game-changer for me. Taking short breaks and staying hydrated has improved my focus and energy throughout the day.&rdquo;</blockquote>
            <div className="testimonial-author d-flex gap-3 align-items-center">
              <div className="author-img"><img className="rounded-circle img-fluid" src="/assets/images/person-sq-1-min.jpg" alt="ATTSpace employee" /></div>
              <div className="lh-base"><strong className="d-block">Priya Sharma</strong><span>Project Manager</span></div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
          <div className="testimonial rounded-4 p-4">
            <blockquote className="mb-3">&ldquo;The TeamPlay Arena has brought our team closer together. Participating in fun challenges like table tennis has made collaboration more enjoyable and strengthened our bond.&rdquo;</blockquote>
            <div className="testimonial-author d-flex gap-3 align-items-center">
              <div className="author-img"><img className="rounded-circle img-fluid" src="/assets/images/person-sq-5-min.jpg" alt="ATTSpace employee" /></div>
              <div className="lh-base"><strong className="d-block">Vikram Singh</strong><span>Data Analyst</span></div>
            </div>
          </div>
        </div>
        {/* Add more testimonials as needed */}
      </div>
    </div>
  </section>
);

export default TestimonialsSection;
