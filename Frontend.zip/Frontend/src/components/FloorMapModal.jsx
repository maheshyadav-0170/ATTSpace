import React, { useEffect, useRef, useState, useCallback } from 'react';
import './FloorMapModal.css';
import layout1 from '../assets/layout-1.png';
import layout2 from '../assets/layout-2.png';

/**
 * FloorMapModal
 * Lightweight carousel modal for displaying workspace layout images.
 * Opens via window.openFloorMap() (registered here) so the FAB can trigger it.
 */
const IMAGES = [
  { src: layout1, alt: 'Workspace Layout 1' },
  { src: layout2, alt: 'Workspace Layout 2' }
];

const FloorMapModal = () => {
  const [open, setOpen] = useState(false);
  const [index, setIndex] = useState(0);
  const dialogRef = useRef(null);

  // Carousel navigation helpers (define BEFORE effects that reference them)
  const next = useCallback(() => setIndex(i => (i + 1) % IMAGES.length), []);
  const prev = useCallback(() => setIndex(i => (i - 1 + IMAGES.length) % IMAGES.length), []);

  const close = useCallback(() => {
    setOpen(false);
    // restore after animation if needed
  }, []);

  const show = useCallback((startIndex = 0) => {
    setIndex(startIndex % IMAGES.length);
    setOpen(true);
  }, []);

  // Expose global trigger
  useEffect(() => {
    window.openFloorMap = show;
    return () => { delete window.openFloorMap; };
  }, [show]);

  // Focus / ESC / Arrow navigation + swipe
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      switch (e.key) {
        case 'Escape':
          close();
          break;
        case 'ArrowRight':
        case 'Right': // legacy fallback
          e.preventDefault();
          next();
          break;
        case 'ArrowLeft':
        case 'Left': // legacy fallback
          e.preventDefault();
          prev();
          break;
        default:
          break;
      }
    };
    window.addEventListener('keydown', onKey, { passive: false });
    // Set focus into dialog to improve screen reader context
    setTimeout(() => { dialogRef.current?.focus(); }, 40);

    // Basic swipe support
    let touchStartX = null;
    let touchStartY = null;
    const onTouchStart = (e) => {
      if (e.touches.length === 1) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }
    };
    const onTouchEnd = (e) => {
      if (touchStartX == null) return;
      const dx = e.changedTouches[0].clientX - touchStartX;
      const dy = e.changedTouches[0].clientY - touchStartY;
      // horizontal swipe threshold
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) {
        if (dx < 0) next(); else prev();
      }
      touchStartX = null; touchStartY = null;
    };
    const carouselEl = dialogRef.current?.querySelector('.floor-map-carousel');
    carouselEl?.addEventListener('touchstart', onTouchStart, { passive: true });
    carouselEl?.addEventListener('touchend', onTouchEnd, { passive: true });

    return () => {
      window.removeEventListener('keydown', onKey);
      carouselEl?.removeEventListener('touchstart', onTouchStart);
      carouselEl?.removeEventListener('touchend', onTouchEnd);
    };
  }, [open, close, next, prev]);

  if (!open) return null;

  return (
    <div className="floor-map-overlay" role="presentation" onClick={close}>
      <div
        className="floor-map-dialog"
        role="dialog"
        aria-modal="true"
        aria-label="Floor map carousel"
        onClick={(e) => e.stopPropagation()}
        tabIndex={-1}
        ref={dialogRef}
      >
        <div className="floor-map-header">
          <h3 className="floor-map-title">Floor Maps</h3>
          <button className="fm-close" aria-label="Close" onClick={close}><i className="fas fa-times" /></button>
        </div>
        <div className="floor-map-carousel">
          {IMAGES.map((img, i) => {
            const active = i === index;
            return (
              <div
                key={img.src}
                className={`fm-slide${active ? ' active' : ''}`}
                aria-hidden={!active}
              >
                <img src={img.src} alt={img.alt} draggable={false} />
              </div>
            );
          })}
          <button type="button" className="fm-nav fm-prev" aria-label="Previous" onClick={prev}><i className="fas fa-chevron-left" /></button>
          <button type="button" className="fm-nav fm-next" aria-label="Next" onClick={next}><i className="fas fa-chevron-right" /></button>
        </div>
        <div className="floor-map-dots" role="tablist" aria-label="Select floor map view">
          {IMAGES.map((_, i) => (
            <button
              key={i}
              type="button"
              className={`fm-dot ${i === index ? 'active' : ''}`}
              aria-label={`Show layout ${i + 1}`}
              aria-selected={i === index}
              onClick={() => setIndex(i)}
            />
          ))}
        </div>
        <div className="fm-footer-hint">Use ← → keys or swipe (touch) to navigate.</div>
      </div>
    </div>
  );
};

export default FloorMapModal;
