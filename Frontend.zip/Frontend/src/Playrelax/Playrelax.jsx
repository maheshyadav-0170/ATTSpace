import { Container, Form, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';
import NavbarComponent from '../HomePage/NavbarComponent';
import '../HomePage/Home.css';
import { API_ENDPOINTS } from '../HomePage/config';

function PlayRelax() {
  const userData = {
    attuid: localStorage.getItem("attuid"),
    firstname: localStorage.getItem("firstname"),
    lastname: localStorage.getItem("lastname"),
  };

  // Invitations state, fetched from backend
  const [invitations, setInvitations] = useState([]);
  const [invitationsLoading, setInvitationsLoading] = useState(true);
  const [invitationsError, setInvitationsError] = useState(null);

  useEffect(() => {
    const fetchInvitations = async () => {
      setInvitationsLoading(true);
      setInvitationsError(null);
      try {
        const token = localStorage.getItem('token');
  const res = await fetch(API_ENDPOINTS.playArena.openGames, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          },
          credentials: 'include',
        });
        if (!res.ok) throw new Error('Failed to fetch open games');
  const data = await res.json();
  // If response has 'games' array, use it; else fallback to data
  setInvitations(Array.isArray(data.games) ? data.games : Array.isArray(data) ? data : []);
      } catch (err) {
        setInvitationsError('Could not load open game invitations.');
      } finally {
        setInvitationsLoading(false);
      }
    };
    fetchInvitations();
  }, []);


  // State for the registration form
  // GameType is the game (chess, carrom, etc.)
  const [gameType, setGameType] = useState('');
  // Remove selectedGame, use only gameType
  // Slot: { date, slotTime }
  // Date field defaults to today
  const todayStr = new Date().toISOString().slice(0, 10);
  const [slotDate, setSlotDate] = useState(todayStr);
  const [slotTime, setSlotTime] = useState('');

  // Available slots from backend
  const [availableSlots, setAvailableSlots] = useState([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slotsError, setSlotsError] = useState(null);

  // Fetch available slots when gameType or slotDate changes
  useEffect(() => {
    if (!gameType || !slotDate) {
      setAvailableSlots([]);
      return;
    }
    const fetchSlots = async () => {
      setSlotsLoading(true);
      setSlotsError(null);
      try {
        const token = localStorage.getItem('token');
  const res = await fetch(API_ENDPOINTS.playArena.availableSlots, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          },
          credentials: 'include',
          body: JSON.stringify({ gameType, date: slotDate }),
        });
        if (!res.ok) throw new Error('Failed to fetch slots');
        const data = await res.json();
        setAvailableSlots(Array.isArray(data.slots) ? data.slots : []);
      } catch (err) {
        setSlotsError('Could not load available slots.');
        setAvailableSlots([]);
      } finally {
        setSlotsLoading(false);
      }
    };
    fetchSlots();
  }, [gameType, slotDate]);
  // Location: dropdown
  const [location, setLocation] = useState('');
  // Remove preferredTime, selectedDate
  const [participants, setParticipants] = useState([]); // selected user IDs
  const [participantToAdd, setParticipantToAdd] = useState('');
  const [allUsers, setAllUsers] = useState([]); // all users for dropdown
  const [registerLoading, setRegisterLoading] = useState(false);
  const [registerSuccess, setRegisterSuccess] = useState(null);
  const [registerError, setRegisterError] = useState(null);

  // Fetch all users for participants dropdown
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const token = localStorage.getItem('token');
  const res = await fetch(API_ENDPOINTS.playArena.allUsers, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          },
          credentials: 'include',
        });
        if (!res.ok) throw new Error('Failed to fetch users');
  const data = await res.json();
  // If response has 'users' array, use it; else fallback to data
  setAllUsers(Array.isArray(data.users) ? data.users : Array.isArray(data) ? data : []);
      } catch (err) {
        setAllUsers([]);
      }
    };
    fetchUsers();
  }, []);

  const handleRegister = async (e) => {
    e.preventDefault();
    setRegisterLoading(true);
    setRegisterSuccess(null);
    setRegisterError(null);
    if (!gameType || !slotDate || !slotTime || !location || participants.length === 0) {
      setRegisterError('Please fill all required fields.');
      setRegisterLoading(false);
      return;
    }
    try {
      const token = localStorage.getItem('token');
      // Parse slotTime value to startTime and endTime
      const [startTime, endTime] = slotTime.split('-');
  const res = await fetch(API_ENDPOINTS.playArena.bookGame, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        },
        credentials: 'include',
        body: JSON.stringify({
          gameType,
          slot: {
            date: slotDate,
            startTime,
            endTime,
          },
          location,
          participants,
          createdBy: userData.attuid,
        }),
      });
      if (!res.ok) throw new Error('Failed to register game');
      setRegisterSuccess('Game registered successfully!');
  setGameType('');
  setSlotDate('');
  setSlotTime('');
  setLocation('');
  setParticipants([]);
    } catch (err) {
      setRegisterError('Failed to register game.');
    } finally {
      setRegisterLoading(false);
    }
  };

  const handleJoin = (invitationId) => {
    // Mock joining a game (replace with API call)
    alert(`You have joined the ${invitations.find(inv => inv.id === invitationId).game} game!`);
    // Optionally remove the invitation or update its status
    setInvitations(invitations.filter(inv => inv.id !== invitationId));
  };

  if (!userData.attuid) {
    return (
      <div className="permission-denied">
        <h2>Permission Denied</h2>
        <p>You do not have access to this page. Please log in or contact support.</p>
        <Link to="/" className="back-button">Back to Landing Page</Link>
      </div>
    );
  }

  // Animation state for expanded card
  const [expandedCard, setExpandedCard] = useState(null);
  const expandTimeoutRef = useRef(null); // used to sequence collapse -> expand for smoother switch

  // Smooth toggle logic: if switching from one card to another, collapse first then expand new
  const handleCardToggle = (cardKey) => {
    if (expandTimeoutRef.current) {
      clearTimeout(expandTimeoutRef.current);
      expandTimeoutRef.current = null;
    }
    // If clicking same card -> collapse
    if (expandedCard === cardKey) {
      setExpandedCard(null);
      return;
    }
    // If another card is expanded, collapse it first then expand the new one after a brief delay
    if (expandedCard && expandedCard !== cardKey) {
      setExpandedCard(null);
      expandTimeoutRef.current = setTimeout(() => {
        setExpandedCard(cardKey);
        expandTimeoutRef.current = null;
      }, 60); // small delay (60ms) gives a smoother sequential feel
      return;
    }
    // No card expanded: just expand
    setExpandedCard(cardKey);
  };

  useEffect(() => {
    return () => {
      if (expandTimeoutRef.current) {
        clearTimeout(expandTimeoutRef.current);
      }
    };
  }, []);

  // Card data for mapping
  const gameCards = [
    {
      key: 'carrom',
      icon: 'fas fa-table',
      title: 'Carrom',
      desc: 'Enjoy a strategic and fun carrom game with colleagues in the play arena.'
    },
    {
      key: 'chess',
      icon: 'fas fa-chess-board',
      title: 'Chess',
      desc: 'Challenge your mind with a classic chess match in a relaxing environment.'
    },
    {
      key: 'foosball',
      icon: 'fas fa-futbol',
      title: 'Foosball',
      desc: 'Engage in an exciting foosball game to unwind and socialize.'
    },
    {
      key: 'table_tennis',
      icon: 'fas fa-table-tennis',
      title: 'Table Tennis',
      desc: 'Experience fast-paced table tennis matches to boost your energy.'
    }
  ];

  // Animation CSS
  // Add this to Home.css:
  // .card {
  //   transition: width 0.4s cubic-bezier(.4,0,.2,1), height 0.4s cubic-bezier(.4,0,.2,1);
  // }
  // .card.expanded {
  //   width: 380px !important;
  //   height: 340px !important;
  //   z-index: 2;
  //   box-shadow: 0 8px 32px rgba(0,0,0,0.18);
  // }

  return (
    <div className="App">
      <NavbarComponent />
      <div className="greeting">
        <h2>
          Welcome to Play & Relax, {userData.firstname || 'User'} {userData.lastname || ''}!
        </h2>
        <p>
          Take a break with fun games in our play arena to unwind and connect with colleagues.
        </p>
      </div>

      <main className="py-5">
        <Container>
          <div style={{ display: 'flex', alignItems: 'center', position: 'relative', marginBottom: '1rem' }}>
            <Link to="/home" className="back-button" style={{ position: 'absolute', left: 0, display: 'inline-flex', alignItems: 'center', marginBottom: 0 }}>
              <i className="fas fa-arrow-circle-left back-icon"></i>
              <span className="back-tooltip">Back to Home</span>
            </Link>
            <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
              <h2 className="section-heading" style={{ marginBottom: 0, textAlign: 'center' }}>Play & Relax</h2>
            </div>
          </div>
          <div className="card-container game-container" id="game-section">
            {gameCards.map(card => {
              const isExpanded = expandedCard === card.key;
              const isShrunk = expandedCard && !isExpanded;
              return (
                <div
                  key={card.key}
                  className={`game-card${isExpanded ? ' expanded' : ''}${isShrunk ? ' shrink' : ''}`}
                  onClick={e => {
                    e.preventDefault();
                    handleCardToggle(card.key);
                  }}
                  aria-expanded={isExpanded}
                  role="button"
                  tabIndex={0}
                  onKeyDown={e => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleCardToggle(card.key);
                    }
                  }}
                >
                  <div className="card-header">
                    <i className={card.icon + " card-icon"}></i>
                    <h3 className="card-title">{card.title}</h3>
                  </div>
                  <div className="card-content" style={{ cursor: 'pointer' }}>
                    <p>{card.desc}</p>
                    <Link
                      to="#"
                      className="read-more"
                      tabIndex={-1}
                      style={{ pointerEvents: 'none', color: '#2b6cb0', fontWeight: 600 }}
                    >Play Now</Link>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="section-heading-container">
            <i className="fas fa-gamepad section-heading-icon"></i>
            <h2 className="section-heading">Play Arena</h2>
          </div>
          <div className="game-container">
            <div className="register-container">
              <hr className="section-divider" />
              <div className="register-header">
                <i className="fas fa-user-plus register-icon"></i>
                <h3 className="register-title">Register for a Game</h3>
                <p className="register-description">Looking for a game partner? Register your interest and let others join you!</p>
                <p className="register-subdescription">Select your preferred game and time to create an open invitation for colleagues.</p>
              </div>
              <div className="register-form">
                <Form onSubmit={handleRegister}>
                  <Form.Group controlId="gameType" className="mb-3">
                    <Form.Label>Game</Form.Label>
                    <Form.Select
                      value={gameType}
                      onChange={e => setGameType(e.target.value)}
                      required
                    >
                      <option value="">Choose a game</option>
                      <option value="carrom">Carrom</option>
                      <option value="chess">Chess</option>
                      <option value="foosball">Foosball</option>
                      <option value="table_tennis">Table Tennis</option>
                    </Form.Select>
                  </Form.Group>
                  <div className="row" style={{ gap: 0 }}>
                    <div className="col-md-6">
                      <Form.Group controlId="slotDate" className="mb-3">
                        <Form.Label>Date</Form.Label>
                        <Form.Control
                          type="date"
                          value={slotDate}
                          min={todayStr}
                          onChange={e => setSlotDate(e.target.value)}
                          required
                        />
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group controlId="slotTime" className="mb-3">
                        <Form.Label>Slot Time</Form.Label>
                        <Form.Select
                          value={slotTime}
                          onChange={e => setSlotTime(e.target.value)}
                          required
                          disabled={slotsLoading || !gameType || !slotDate}
                        >
                          <option value="">{slotsLoading ? 'Loading slots...' : 'Select slot time'}</option>
                          {slotsError && <option value="" disabled>{slotsError}</option>}
                          {availableSlots
                            .filter(slot => {
                              // For today, only show future slots
                              if (slotDate !== todayStr) return true;
                              const now = new Date();
                              const [h, m] = slot.startTime.split(':');
                              const slotDateTime = new Date();
                              slotDateTime.setHours(Number(h), Number(m), 0, 0);
                              return slotDateTime > now;
                            })
                            .map(slot => {
                              const value = `${slot.startTime}-${slot.endTime}`;
                              const label = `${slot.startTime} - ${slot.endTime}`;
                              return <option key={value} value={value}>{label}</option>;
                            })}
                        </Form.Select>
                      </Form.Group>
                    </div>
                  </div>
                  <Form.Group controlId="location" className="mb-3">
                    <Form.Label>Location</Form.Label>
                    <div style={{ display: 'flex', gap: '2rem', alignItems: 'center', marginTop: '6px', justifyContent: 'center' }}>
                      <Form.Check
                        type="radio"
                        id="location-10th"
                        label="10th Floor"
                        name="location"
                        value="10th Floor"
                        checked={location === '10th Floor'}
                        onChange={e => setLocation(e.target.value)}
                        required
                      />
                      <Form.Check
                        type="radio"
                        id="location-11th"
                        label="11th Floor"
                        name="location"
                        value="11th Floor"
                        checked={location === '11th Floor'}
                        onChange={e => setLocation(e.target.value)}
                        required
                      />
                    </div>
                  </Form.Group>
                  <Form.Group controlId="participants" className="mb-3">
                    <Form.Label>Participants (max 3)</Form.Label>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <Form.Select
                        value={participantToAdd}
                        onChange={e => setParticipantToAdd(e.target.value)}
                        disabled={participants.length >= 3}
                      >
                        <option value="">Select user</option>
                        {allUsers.filter(user => !participants.includes(user.attuid)).map(user => (
                          <option key={user.attuid} value={user.attuid}>
                            {user.firstname || ''} {user.lastname || ''} ({user.attuid})
                          </option>
                        ))}
                      </Form.Select>
                      <Button
                        variant="success"
                        size="sm"
                        type="button"
                        disabled={!participantToAdd || participants.length >= 3}
                        onClick={() => {
                          if (participantToAdd && !participants.includes(participantToAdd) && participants.length < 3) {
                            setParticipants([...participants, participantToAdd]);
                            setParticipantToAdd('');
                          }
                        }}
                      >Add</Button>
                    </div>
                    <div style={{ marginTop: 8 }}>
                      {participants.length === 0 && <span style={{ color: '#888' }}>No participants added.</span>}
                      {participants.map((attuid, idx) => {
                        const user = allUsers.find(u => u.attuid === attuid);
                        const display = user ? `${user.firstname || ''} ${user.lastname || ''} (${user.attuid})` : attuid;
                        return (
                          <div key={attuid} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                            <span>{display}</span>
                            <Button
                              variant="danger"
                              size="sm"
                              type="button"
                              onClick={() => setParticipants(participants.filter(p => p !== attuid))}
                            >Remove</Button>
                          </div>
                        );
                      })}
                    </div>
                  </Form.Group>
                  <Button variant="primary" type="submit" className="logout-btn" disabled={registerLoading}>
                    {registerLoading ? 'Registering...' : 'Register'}
                  </Button>
                  {registerSuccess && <div className="text-success mt-2">{registerSuccess}</div>}
                  {registerError && <div className="text-danger mt-2">{registerError}</div>}
                </Form>
              </div>
              <hr className="section-divider" />
            </div>

            <div className="invitations-container">
              <hr className="section-divider" />
              <div className="invitations-header">
                <i className="fas fa-users invitations-icon"></i>
                <h3 className="invitations-title">Open Game Invitations</h3>
                <p className="invitations-description">Join a game posted by colleagues from other teams!</p>
                <p className="invitations-subdescription">Browse available games and join one that fits your schedule.</p>
              </div>
              <div className="invitations-list" style={{ maxHeight: 350, overflowY: 'auto', paddingRight: 8 }}>
                {invitationsLoading ? (
                  <p className="no-invitations">Loading open invitations...</p>
                ) : invitationsError ? (
                  <p className="no-invitations text-danger">{invitationsError}</p>
                ) : invitations.length === 0 ? (
                  <p className="no-invitations">No open invitations at the moment.</p>
                ) : (
                  invitations.map((invitation) => {
                    // Icon selection based on gameType
                    let iconClass = '';
                    switch ((invitation.gameType || '').toLowerCase()) {
                      case 'carrom':
                        iconClass = 'fas fa-table'; break;
                      case 'chess':
                        iconClass = 'fas fa-chess-board'; break;
                      case 'foosball':
                        iconClass = 'fas fa-futbol'; break;
                      case 'table_tennis':
                        iconClass = 'fas fa-table-tennis'; break;
                      default:
                        iconClass = 'fas fa-gamepad';
                    }

                    // Format date and time
                    let dateStr = '';
                    let timeStr = '';
                    if (invitation.slot && invitation.slot.date) {
                      // Format date as YYYY-MM-DD or locale string
                      const d = new Date(invitation.slot.date);
                      dateStr = d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
                    }
                    if (invitation.slot && invitation.slot.startTime && invitation.slot.endTime) {
                      // Format time as HH:mm AM/PM
                      const formatTime = t => {
                        const [h, m] = t.split(':');
                        const date = new Date();
                        date.setHours(Number(h), Number(m));
                        return date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
                      };
                      timeStr = `${formatTime(invitation.slot.startTime)} - ${formatTime(invitation.slot.endTime)}`;
                    }

                    return (
                      <div key={invitation.id || invitation._id} className="invitation-item">
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                          <i className={iconClass + ' invitation-game-icon'} style={{ fontSize: 24 }}></i>
                          <div>
                            <strong style={{ textTransform: 'capitalize' }}>{invitation.gameType || invitation.game || invitation.gameName}</strong>
                            {invitation.location && (
                              <span style={{ marginLeft: 8, color: '#555' }}>@ {invitation.location}</span>
                            )}
                            {dateStr && timeStr && (
                              <span style={{ marginLeft: 8, color: '#555' }}>
                                on {dateStr} ({timeStr})
                              </span>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="primary"
                          className="logout-btn"
                          style={{ marginTop: 8 }}
                          onClick={() => handleJoin(invitation.id || invitation._id)}
                        >
                          Join Game
                        </Button>
                      </div>
                    );
                  })
                )}
              </div>
              <hr className="section-divider" />
            </div>
          </div>
        </Container>
      </main>
    </div>
  );
}

export default PlayRelax;