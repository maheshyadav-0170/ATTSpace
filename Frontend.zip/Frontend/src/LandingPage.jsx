import { useState, useEffect } from 'react';
import PublicNavbar from './components/nav/PublicNavbar';

function LandingPage() {
  const [ipconfigOutput, setIpconfigOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [userWorkMode, setUserWorkMode] = useState('');

  useEffect(() => {
    const runIpconfig = async () => {
      setLoading(true);
      try {
        const result = await window.electronAPI.runIpconfig();
        setIpconfigOutput(result);
        // Parse for office DNS
        const dnsSuffixRegex = /Connection-specific DNS Suffix\s*\.\s*:\s*(.*)/gi;
        let foundOffice = false;
        let match;
        while ((match = dnsSuffixRegex.exec(result)) !== null) {
          if (match[1] && match[1].trim().toLowerCase() === 'intl.att.com') {
            foundOffice = true;
            break;
          }
        }
        setUserWorkMode(foundOffice ? 'office' : 'remote');
      } catch (err) {
        setIpconfigOutput('Error running ipconfig');
        setUserWorkMode('unknown');
      }
      setLoading(false);
    };
    runIpconfig();
  }, []);
  return (
    <div className="App">
      <PublicNavbar />

      {/* Landing Content */}
      <div style={{ padding: '40px 20px', textAlign: 'center' }}>
        <h1>Welcome to Attspace</h1>
        <p>Discover a modern workspace solution. Click <a href="/home">here</a> to enter your dashboard.</p>
        <hr />
        {/* Automatically runs ipconfig on load, button removed for automation */}
        {loading && (
          <div style={{marginTop: 20}}>Loading network info...</div>
        )}
        {!loading && (
          <>
            <div style={{marginTop: 20, fontSize: '1.2em', fontWeight: 'bold'}}>
              Network Mode: {userWorkMode === 'office' ? 'Office' : userWorkMode === 'remote' ? 'Remote' : 'Unknown'}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default LandingPage;