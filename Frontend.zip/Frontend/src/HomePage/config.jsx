// Central service base URLs. Avoid using logical OR (||) so empty strings are not treated as false.
// Use nullish coalescing (??) + trimming. If you do not want ANY default, remove the fallback string.

const clean = (v) => (typeof v === 'string' ? v.trim().replace(/\/$/, '') : v);
const env = import.meta.env;

// Provide explicit fallback only if variable is null/undefined (not for empty string)
const AUTH_BASE_URL = clean(env.VITE_AUTH_BASE_URL ?? 'http://localhost:4000');
const NOTIFICATIONS_BASE_URL = clean(env.VITE_NOTIFICATIONS_BASE_URL ?? 'http://localhost:4001');
const PROFILE_BASE_URL = clean(env.VITE_PROFILE_BASE_URL ?? 'http://localhost:4003');
const PLAY_ARENA_BASE_URL = clean(env.VITE_PLAY_ARENA_BASE_URL ?? 'http://localhost:4004');

export const API_ENDPOINTS = {
  profile: {
    get: `${PROFILE_BASE_URL}/profile/get`,
    update: `${PROFILE_BASE_URL}/profile/update`, // Example endpoint
  },
  notifications: {
    fetch: `${NOTIFICATIONS_BASE_URL}/notifications/fetch`,
    read: `${NOTIFICATIONS_BASE_URL}/notifications/read`,
    readall: `${NOTIFICATIONS_BASE_URL}/notifications/readall`
  },
  playArena: {
    openGames: `${PLAY_ARENA_BASE_URL}/play-arena/open-arena-games`,
    availableSlots: `${PLAY_ARENA_BASE_URL}/play-arena/available-slots`,
    allUsers: `${PLAY_ARENA_BASE_URL}/play-arena/get-all-users`,
    bookGame: `${PLAY_ARENA_BASE_URL}/play-arena/book-arena-game`,
  },
  auth: {
    login: `${AUTH_BASE_URL}/auth/login`, // Example endpoint
    logout: `${AUTH_BASE_URL}/auth/logout`, // Example endpoint
    refresh: `${AUTH_BASE_URL}/auth/refresh`, // Example endpoint
    homeStatus: `${AUTH_BASE_URL}/auth/home`,
  },
  // Add more services as needed, e.g.:
  // reservation: {
  //   book: `${RESERVATION_BASE_URL}/reservation/book`,
  //   list: `${RESERVATION_BASE_URL}/reservation/list`,
  // },
};