import { app, BrowserWindow, ipcMain, Menu } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  // Hide the default menu for this window and remove it entirely
  try {
    win.setMenuBarVisibility(false);
    win.removeMenu();
  } catch (e) {
    // ignore if APIs are not available for some platforms
  }

  // Always load Vite dev server in development phase
  win.loadURL('http://localhost:5173');
}

app.whenReady().then(() => {
  // Remove the application menu globally (prevents File/Edit menu on Windows/Linux)
  try {
    Menu.setApplicationMenu(null);
  } catch (e) {
    // ignore on older Electron versions or platforms where it isn't supported
  }
  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
import { exec } from 'child_process';
ipcMain.handle('run-ipconfig', async () => {
  return new Promise((resolve) => {
    exec('ipconfig', (error, stdout, stderr) => {
      if (error) {
        resolve(stderr || error.message);
        return;
      }
      resolve(stdout);
    });
  });
});
