const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  runIpconfig: () => ipcRenderer.invoke('run-ipconfig'),
  notifications: {
    connectWebSocket: (onMessage) => {
      const ws = new window.WebSocket('ws://localhost:4001');
      ws.onmessage = (event) => {
        if (onMessage) onMessage(JSON.parse(event.data));
      };
      return ws;
    }
  },
  setAttuid: (attuid) => ipcRenderer.send('set-attuid', attuid)
});
